import sys,pathlib,json,os,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent));from full_scene import *
from render_bounds import bounds
D=P/'render';D.mkdir(exist_ok=True);B=P/'blends';B.mkdir(exist_ok=True)
lo=int(os.getenv('CUT_START','1'));hi=int(os.getenv('CUT_END','40'));stats=[]
for i in range(lo,hi+1):
 existing=D/f'cut_{i:02d}'
 if (existing/'complete.json').exists() and json.loads((existing/'complete.json').read_text()).get('complete') is True:
  print('REUSE_COMPLETE_NATIVE_CUT',i,flush=True);continue
 s,cam,focus,c=build(i);out=D/f'cut_{i:02d}';out.mkdir(exist_ok=True)
 s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=10;s.render.use_border=False;s.render.use_crop_to_border=False
 bpy.ops.wm.save_as_mainfile(filepath=str(B/f'cut_{i:02d}.blend'),compress=True)
 roi=(0,0,1,1) if i in [7,9,16,27,30,31,39,40] else bounds(s,cam);use_region=(roi[2]-roi[0])*(roi[3]-roi[1])<.92
 if use_region:
  s.render.filepath=str(out/'plate.png');bpy.ops.render.render(write_still=True)
  s.render.use_border=True;s.render.use_crop_to_border=True;s.render.border_min_x,s.render.border_min_y,s.render.border_max_x,s.render.border_max_y=roi
 print('NATIVE_ROI',i,roi,use_region,flush=True)
 meta={'cut':i,'start_frame':s.frame_start,'end_frame':s.frame_end,'region':use_region,'x0':roi[0],'y0':roi[1],'x1':roi[2],'y1':roi[3],'scene':c};(out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 s.render.filepath=str(out/'#####');s.render.use_overwrite=False;last=time.time()
 def completed(scene):
  global last
  now=time.time();f=scene.frame_current;progress={'cut':i,'global_frame':f,'total_frames':3435,'seconds':(f-1)/24,'render_seconds':now-last};last=now;(D/'progress.json').write_text(json.dumps(progress));print('FRAME_DONE',json.dumps(progress),flush=True)
 bpy.app.handlers.render_write.append(completed)
 bpy.ops.render.render(animation=True)
 bpy.app.handlers.render_write.remove(completed)
 stats.append(c);(out/'complete.json').write_text(json.dumps({'complete':True,'frames':s.frame_end-s.frame_start+1}));(P/f'scene_table_{lo}_{hi}.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2));print('CUT_DONE',i,flush=True)
