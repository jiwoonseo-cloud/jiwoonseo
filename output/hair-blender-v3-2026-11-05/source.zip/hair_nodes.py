import bpy,math
def attach_hair_nodes(obj,controller,count=90,n=168,base_radius=.205,height=.75,target_x=.945,target_radius=.047,end_start=.905,spread=.18,lengths=None):
 data=obj.data
 lengths=lengths or [2+(j%11)*.065 for j in range(count)]
 for name,values in [('strand_index',[float(j) for j in range(count) for _ in range(n)]),('arc_length',[lengths[j]*k/(n-1) for j in range(count) for k in range(n)]),('total_length',[lengths[j] for j in range(count) for _ in range(n)])]:
  attr=data.attributes.get(name) or data.attributes.new(name,'FLOAT','POINT');attr.data.foreach_set('value',values)
 tree=bpy.data.node_groups.new('Continuous physical strand winding and end migration','GeometryNodeTree');tree.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry');tree.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
 sockets={name:tree.interface.new_socket(name=name,in_out='INPUT',socket_type='NodeSocketFloat') for name in ['Wind','Slide','Angle']}
 nodes=tree.nodes;links=tree.links;inp=nodes.new('NodeGroupInput');out=nodes.new('NodeGroupOutput')
 def attr(name):
  o=nodes.new('GeometryNodeInputNamedAttribute');o.data_type='FLOAT';o.inputs['Name'].default_value=name;return o.outputs['Attribute']
 def connect(value,socket):
  if isinstance(value,(float,int)):socket.default_value=value
  else:links.new(value,socket)
 def mathnode(op,*values):
  o=nodes.new('ShaderNodeMath');o.operation=op
  for value,socket in zip(values,o.inputs):connect(value,socket)
  return o.outputs[0]
 def add(a,b):return mathnode('ADD',a,b)
 def sub(a,b):return mathnode('SUBTRACT',a,b)
 def mul(a,b):return mathnode('MULTIPLY',a,b)
 def div(a,b):return mathnode('DIVIDE',a,b)
 def sin(a):return mathnode('SINE',a)
 def cos(a):return mathnode('COSINE',a)
 def vector(x,y,z):
  o=nodes.new('ShaderNodeCombineXYZ')
  for val,sock in zip([x,y,z],o.inputs):connect(val,sock)
  return o.outputs[0]
 j,s,L=attr('strand_index'),attr('arc_length'),attr('total_length');wind,slide,angle=[inp.outputs[k] for k in ['Wind','Slide','Angle']]
 xbase=add(mul(mul(spread,sin(mul(j,1.71))),sub(1,slide)),mul(slide,add(target_x,mul(max(.005,math.sqrt(count)*.002),sin(mul(j,2.1))))))
 contraction=mathnode('MINIMUM',1,mathnode('MAXIMUM',0,div(sub(xbase,end_start),.04)));contraction=mul(mul(contraction,contraction),sub(3,mul(2,contraction)))
 radius=add(add(mul(base_radius,sub(1,contraction)),mul(target_radius,contraction)),mul(.0008,mathnode('FLOOR',div(j,max(1,int(math.sqrt(count)))))))
 phi=add(angle,mul(.25,sin(mul(j,1.7))));wound=mathnode('MINIMUM',L,mul(wind,4*math.pi*base_radius))
 theta=sub(phi,div(s,radius));wound_p=vector(add(xbase,mul(.025/(2*math.pi),s)),mul(radius,cos(theta)),mul(radius,sin(theta)))
 q=sub(s,wound);endangle=sub(phi,div(wound,radius));cy=mul(radius,cos(endangle));cz=mul(radius,sin(endangle));decay=mathnode('EXPONENT',div(mul(-1,q),.05))
 free_x=add(add(xbase,mul(.025/(2*math.pi),wound)),mul(mul(.025,sub(sin(add(mul(q,4),j)),sin(j))),sub(1,decay)))
 drop=mathnode('MAXIMUM',0,add(height,cz));free_p=vector(free_x,add(cy,mathnode('MAXIMUM',0,sub(q,drop))),sub(cz,mathnode('MINIMUM',q,drop)))
 switch=nodes.new('GeometryNodeSwitch');switch.input_type='VECTOR';links.new(mathnode('LESS_THAN',s,wound),switch.inputs['Switch']);links.new(free_p,switch.inputs['False']);links.new(wound_p,switch.inputs['True'])
 setpos=nodes.new('GeometryNodeSetPosition');links.new(inp.outputs['Geometry'],setpos.inputs['Geometry']);links.new(switch.outputs[0],setpos.inputs['Position']);links.new(setpos.outputs['Geometry'],out.inputs['Geometry'])
 # A native Geometry Nodes rig, driven by keyed custom properties. It remains
 # animated in the delivered .blend without any frame-change Python callback.
 mod=obj.modifiers.new('Keyframed strand physics controls','NODES');mod.node_group=tree
 for label,prop in [('Wind','wind'),('Slide','slide'),('Angle','angle')]:
  key=sockets[label].identifier;mod[key]=0.0;d=mod.driver_add(f'["{key}"]').driver;d.type='AVERAGE';v=d.variables.new();v.name='control';v.type='SINGLE_PROP';v.targets[0].id=controller;v.targets[0].data_path=f'["{prop}"]'
 return mod

def relax_severed_strands(obj,parts,start,cuttime,release_duration=.465,forward=.045,scatter=0):
 """Elastic release after cutting: disconnected curved pieces become loose hairs."""
 target=[]
 for j,part in enumerate(parts):
  distance=0.0;last=part[0];length=max(1e-6,sum(math.sqrt(sum((a[k]-b[k])**2 for k in range(3))) for a,b in zip(part,part[1:])))
  for p in part:
   distance+=math.sqrt(sum((p[k]-last[k])**2 for k in range(3)));last=p;w=min(1,distance/.035)
   along=min(1,distance/length);fan=.14*math.sin(j*2.399963)*along**.8
   target.extend((part[0][0]+.012*math.sin(13*distance+j*.73)*w+fan+scatter*.7*math.sin(j*.81),forward+.012*math.sin(9*distance+j*1.1)*w+.025*math.cos(j*.63)*along+scatter*.35*math.cos(j*.71),scatter*math.sin(j*1.13)+.006*math.cos(j*1.7)-.92*distance*(.96+.04*math.sin(j))))
 attr=obj.data.attributes.new('loose_hair_target','FLOAT_VECTOR','POINT');attr.data.foreach_set('vector',target)
 tree=bpy.data.node_groups.new('Cut hair releases into individual hanging wisps','GeometryNodeTree');tree.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry');tree.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry');amount=tree.interface.new_socket(name='Release',in_out='INPUT',socket_type='NodeSocketFloat')
 nodes,links=tree.nodes,tree.links;inp=nodes.new('NodeGroupInput');out=nodes.new('NodeGroupOutput');pos=nodes.new('GeometryNodeInputPosition');named=nodes.new('GeometryNodeInputNamedAttribute');named.data_type='FLOAT_VECTOR';named.inputs['Name'].default_value='loose_hair_target'
 sub=nodes.new('ShaderNodeVectorMath');sub.operation='SUBTRACT';links.new(named.outputs['Attribute'],sub.inputs[0]);links.new(pos.outputs[0],sub.inputs[1]);sc=nodes.new('ShaderNodeVectorMath');sc.operation='SCALE';links.new(sub.outputs[0],sc.inputs[0]);links.new(inp.outputs['Release'],sc.inputs['Scale']);setp=nodes.new('GeometryNodeSetPosition');links.new(inp.outputs['Geometry'],setp.inputs['Geometry']);links.new(sc.outputs[0],setp.inputs['Offset']);links.new(setp.outputs[0],out.inputs['Geometry'])
 mod=obj.modifiers.new('Natural relaxation of cut strands','NODES');mod.node_group=tree;socket=amount.identifier
 for sec,value in [(start,0),(cuttime+.035,0),(cuttime+.035+release_duration,1)]:mod[socket]=float(value);mod.keyframe_insert(data_path=f'["{socket}"]',frame=sec*24+1)
 if obj.animation_data and obj.animation_data.action:
  for f in obj.animation_data.action.fcurves:
   for k in f.keyframe_points:k.interpolation='LINEAR'
 return mod

def damaged_fin_position(co,inner_radius,outer_radius,length):
 x,y,z=co;r=math.hypot(y,z);w=max(0,min(1,(r-inner_radius)/max(.001,outer_radius-inner_radius)));bell=max(0,1-(x/(length*.49))**2)**2
 angle=math.atan2(z,y)-1.25*w*bell;radius=max(inner_radius+.004*w,r-.035*w*bell)
 return (x+.17*w*bell*math.sin(x*6+1),radius*math.cos(angle),radius*math.sin(angle))

def bend_brush_bristles(obj,start,at,end,radius=.18,length=2.2):
 """Native per-fibre circular bends, with anchors following buckled rubber fins."""
 positions=[tuple(p.vector) for p in obj.data.attributes['position'].data];target=[]
 assert len(positions)%3==0
 for j in range(len(positions)//3):
  anchor=positions[j*3];tip=positions[j*3+2];rib=j//72;L=math.sqrt(sum((tip[k]-anchor[k])**2 for k in range(3)));origin=damaged_fin_position(anchor,radius-.004,radius+.043,length) if rib in [0,5] else anchor
  phi=math.atan2(origin[2],origin[1]);cy,sz=math.cos(phi),math.sin(phi);theta=2.15+.15*math.sin(j*.7)
  for k in range(3):
   u=k/2;radial=L*math.sin(theta*u)/theta;tangent=L*(1-math.cos(theta*u))/theta
   target.extend((origin[0]+.003*u,origin[1]+radial*cy-tangent*sz,origin[2]+radial*sz+tangent*cy))
 attr=obj.data.attributes.new('Bent bristle target','FLOAT_VECTOR','POINT');attr.data.foreach_set('vector',target)
 tree=bpy.data.node_groups.new('Nylon bristles visibly bend under damage','GeometryNodeTree');tree.interface.new_socket(name='Geometry',in_out='INPUT',socket_type='NodeSocketGeometry');tree.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry');amount=tree.interface.new_socket(name='Damage',in_out='INPUT',socket_type='NodeSocketFloat')
 nodes,links=tree.nodes,tree.links;inp=nodes.new('NodeGroupInput');out=nodes.new('NodeGroupOutput');pos=nodes.new('GeometryNodeInputPosition');named=nodes.new('GeometryNodeInputNamedAttribute');named.data_type='FLOAT_VECTOR';named.inputs['Name'].default_value='Bent bristle target'
 delta=nodes.new('ShaderNodeVectorMath');delta.operation='SUBTRACT';links.new(named.outputs['Attribute'],delta.inputs[0]);links.new(pos.outputs[0],delta.inputs[1]);weight=nodes.new('ShaderNodeVectorMath');weight.operation='SCALE';links.new(delta.outputs[0],weight.inputs[0]);links.new(inp.outputs['Damage'],weight.inputs['Scale']);setp=nodes.new('GeometryNodeSetPosition');links.new(inp.outputs['Geometry'],setp.inputs['Geometry']);links.new(weight.outputs[0],setp.inputs['Offset']);links.new(setp.outputs[0],out.inputs['Geometry'])
 mod=obj.modifiers.new('Keyframed individual bristle bending','NODES');mod.node_group=tree;socket=amount.identifier
 for sec,val in [(start,0.0),(at,0.0),(end,1.0)]:mod[socket]=float(val);mod.keyframe_insert(data_path=f'["{socket}"]',frame=sec*24+1)
 for fc in obj.animation_data.action.fcurves:
  for point in fc.keyframe_points:point.interpolation='LINEAR'
