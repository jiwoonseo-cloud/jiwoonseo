"""Native, keyed Blender scenes. Modeling units are magnified for macro views; time is seconds of original voice."""
import sys,json,math,random,pathlib
import bpy
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from assets import *
from props import *
from hair_nodes import attach_hair_nodes,relax_severed_strands,damaged_fin_position,bend_brush_bristles
from mathutils import Matrix
P=pathlib.Path(str(pathlib.Path(__file__).resolve().parent));PLAN=json.loads((P/'plan.json').read_text());CUTS=PLAN['cuts']
def key(o,path,t,value,index=-1):
 if index<0:setattr(o,path,value);o.keyframe_insert(data_path=path,frame=t*24+1)
 else:getattr(o,path)[index]=value;o.keyframe_insert(data_path=path,index=index,frame=t*24+1)
def linear(o):
 if o.animation_data and o.animation_data.action:
  for f in o.animation_data.action.fcurves:
   for k in f.keyframe_points:k.interpolation='CONSTANT' if f.data_path.endswith('hide_render') else 'LINEAR'
def move(o,a,b,t0,t1):key(o,'location',t0,a);key(o,'location',t1,b);linear(o)
def rotate(o,angle0,angle1,t0,t1,axis=0):key(o,'rotation_euler',t0,angle0,axis);key(o,'rotation_euler',t1,angle1,axis);linear(o)
def scale(o,a,b,t0,t1):key(o,'scale',t0,(a,a,a));key(o,'scale',t1,(b,b,b));linear(o)
def cue(c,word,edge='start',fallback=None):
 for w in c['words']:
  if word in w['word']:return w[edge]
 return fallback if fallback is not None else c['start']+.25

def hairrig(M,roll,count=80,wind=1.05,slide=0,height=.75,radius=.205,spread=.18,lengths=None,target=.945,end=.905,target_radius=.047):
 h=make_hair(M,count);h.location.z=height
 ctrl=empty('Hair winding/migration controls');ctrl['wind']=float(wind);ctrl['slide']=float(slide);ctrl['angle']=float(wind)*4*math.pi
 attach_hair_nodes(h,ctrl,count=count,base_radius=radius,height=height,spread=spread,lengths=lengths,target_x=target,end_start=end,target_radius=target_radius)
 d=roll['spin'].driver_add('rotation_euler',0).driver;d.type='AVERAGE';v=d.variables.new();v.name='actual_rotation';v.type='SINGLE_PROP';v.targets[0].id=ctrl;v.targets[0].data_path='["angle"]'
 return h,ctrl

def controls(ctrl,name,points):
 for t,val in points:ctrl[name]=float(val);ctrl.keyframe_insert(data_path=f'["{name}"]',frame=t*24+1)
 linear(ctrl)

def sever(h,M,t0,cuttime,relax=False,release_duration=.465,release_forward=.045,release_scatter=0):
 """Split native hair splines at the forward cutting plane, preserve endpoints."""
 scene=bpy.context.scene;scene.frame_set(round(cuttime*24)+1);bpy.context.view_layer.update();data=h.evaluated_get(bpy.context.evaluated_depsgraph_get()).data
 pos=[tuple(p.vector) for p in data.attributes['position'].data];parts=[]
 for start in range(0,len(pos),168):
  strand=pos[start:start+168];first=0
  for k in range(1,len(strand)):
   a,b=strand[k-1],strand[k]
   if a[1]>.015 and b[1]>.015 and a[2]*b[2]<0:
    f=abs(a[2])/(abs(a[2])+abs(b[2]));q=tuple(a[v]+f*(b[v]-a[v]) for v in range(3));part=strand[first:k]+[q]
    if len(part)>1:parts.append(part)
    strand[k-1]=q;first=k-1
  if len(strand[first:])>1:parts.append(strand[first:])
 pieces=curves('Actually severed hair pieces',parts,M['hair'],.001);pieces.location=h.location.copy()
 if relax:relax_severed_strands(pieces,parts,t0,cuttime,release_duration=release_duration,forward=release_forward,scatter=release_scatter)
 key(h,'hide_render',t0,False);key(h,'hide_render',cuttime,True);key(pieces,'hide_render',t0,True);key(pieces,'hide_render',cuttime,False)
 return pieces

def studio(M):
 cube('Physical neutral studio bench',(0,0,-.06),(1000,1000,.12),M['floor'],edge=.02)
 profile=[(3-3*math.cos(math.pi*k/24),8+3*math.sin(math.pi*k/24)) for k in range(13)]+[(9,11)]
 cyc=lathe('Seamless curved studio cyclorama',profile,M['floor'],axis='Z',seg=96)
 import bmesh
 bm=bmesh.new();bm.from_mesh(cyc.data);bmesh.ops.reverse_faces(bm,faces=list(bm.faces));bm.to_mesh(cyc.data);bm.free()

def benchroller(M,name='Main roller',height=.75):
 r=roller(M,name);r['root'].location.z=height
 for side in [-1,1]:
  cube('Rounded roller service cradle',(side*1.03,-.10,(height-.13)/2),(.10,.13,height-.13),M['white'],edge=.025)
  cube('Metal cradle foot',(side*1.03,0,.023),(.26,.38,.046),M['metal'],edge=.02)
 return r

def dirt(M,c,mode='up',n=32,location=(0,0,.1),duration=None,emission_fraction=.5):
 rng=random.Random(765+c['cut']);root=empty('Individual airborne particles');t0=c['start'];t1=c['end'];D=duration or (t1-t0)*.8
 for j in range(n):
  a=t0+(t1-t0)*emission_fraction*j/max(n-1,1);dt=min(.9,D);x=location[0]+rng.uniform(-.42,.42);y=location[1]+rng.uniform(-.25,.25);z=location[2]
  if mode=='fur':
   pts=[(0,0,0),(.04,.005,.01),(.075,-.003,.015)];o=curves('Separate short pet hair',[pts],M['hair'],.0015,root)
  else:o=sphere('Separate floating dust particle',(0,0,0),(.013,.010,.009),M['bristle'],root,12)
  move(o,(x,y,z),(location[0]+x*.1,location[1],z+1.1),a,min(a+dt,t1-.05));base=tuple(o.scale);key(o,'scale',a,base);key(o,'scale',min(a+dt,t1-.05),tuple(v*.03 for v in base));linear(o)
 return root

def residual_duo(M,c,count=30,row=0,height=.75,length=.85,center=.5):
 pairs=[]
 for side in [-1,1]:
  r=roller(M,'Improved split roller with residual hair',length,.16,ends=(side,),helical=True);r['root'].location=(side*center,row,height)
  h,q=hairrig(M,r,count,1.1,1,height=height,spread=.08,target=length/2+.04,end=length/2+.005)
  h.location=(side*center,row,height);h.scale.x=side
  controls(q,'angle',[(c['start'],0),(c['end'],side*TAU*1.5)])
  for cap in r['caps']:
   for ob in [cap]+list(cap.children_recursive):ob.hide_render=True
  pairs.append((r,h,q))
 return pairs

def physical_dial(M,c):
 root=empty('Adjustable suction control');lathe('Fluted suction dial',[(0,.18),(.02,.23),(.08,.23),(.10,.20)],M['white'],root,'Z',48)
 for j in range(24):
  a=TAU*j/24;cube('Dial moulded grip',( .222*math.cos(a),.222*math.sin(a),.05),(.012,.012,.055),M['black'],root,.003)
 knob=empty('Rotating dial pointer',root);cube('Knob index',(.13,0,.108),(.10,.018,.012),M['accent'],knob,.004)
 for j in range(11):
  a=math.pi*.8+math.pi*1.4*j/10;cube('Engraved dial tick',(.30*math.cos(a),.30*math.sin(a),.005),(.025,.009,.004),M['black'],root,.001)
 rotate(knob,0,math.pi*1.3,cue(c,'세게',fallback=c['start']+.2),c['end']-.25,2)
 h=hand(M,gap=.08);h.parent=root;h.location=(.18,0,.12);rotate(h,0,math.pi*.6,cue(c,'세게',fallback=c['start']+.2),c['end']-.25,2)
 return root

def build(cutno):
 c=CUTS[cutno-1];t0,t1=c['start'],c['end'];s,cam,focus=setup('BLENDER_EEVEE_NEXT',1);M=materials();s.eevee.use_gtao=False;s.eevee.shadow_resolution_scale=.25;s.eevee.bokeh_max_size=8
 for l in bpy.data.lights:l.use_shadow=l.name.startswith('Large')
 for o in bpy.data.objects:
  if o.type=='LIGHT' and o.name.startswith('Large'):o.location.y=4;aim(o,(0,0,.5))
 # Avoid expensive microscopic procedural bump; real moulded profiles, PBR and bevels remain.
 for m in bpy.data.materials:
  if m.use_nodes:
   p=m.node_tree.nodes.get('Principled BSDF')
   if p:
    for l in list(p.inputs['Normal'].links):m.node_tree.links.remove(l)
 studio(M);camloc=(2.3,5.5,2.6);target=(0,0,.62);lens=50;description=''
 def rmain(wind=1.05,slide=0,count=80):
  r=benchroller(M);h,q=hairrig(M,r,count,wind,slide);return r,h,q
 def spin(q,w0,w1,a,b):
  controls(q,'wind',[(t0,w0),(a,w0),(b,w1),(t1,w1)]);controls(q,'angle',[(t0,w0*4*math.pi),(a,w0*4*math.pi),(b,w1*4*math.pi),(t1,w1*4*math.pi)])
 def drift(q,a,b,start=0,end=1):controls(q,'slide',[(t0,start),(a,start),(b,end),(t1,end)])
 if cutno==1:
  bpy.data.objects['Physical neutral studio bench'].hide_render=True;bpy.data.objects['Seamless curved studio cyclorama'].hide_render=True;room(M);bot=robot(M);bot['root'].scale=(.26,.26,.26);move(bot['root'],(0,.65,-.1554),(0,-.45,-.1554),cue(c,'로봇'),t1-.3);rotate(bot['roller']['spin'],0,TAU*2,t0,t1)
  for wheel in bot['wheels']:rotate(wheel,0,4.4,t0,t1)
  rng=random.Random(7);curves('Loose long hair on oak floor',[[(-.25+j*.025,.1+k*.02,-.208+.001*math.sin(k*.3+j)) for k in range(40)] for j in range(22)],M['hair'],.0008)
  camloc=(1.5,-2.4,.48);target=(0,-.1,-.03);lens=55;description='바닥에 펼쳐진 개별 가닥 위로 본체가 전진하며 설치 롤러 회전'
 elif cutno in [2,37]:
  bot=robot(M);root=bot['root'];left=hand(M,'Left hand lifting chassis',True);right=hand(M,'Right hand lifting chassis');left.parent=root;right.parent=root;left.location=(-1.32,0,.15);right.location=(1.32,0,.15)
  if cutno==2:
   installed_hair,installed_control=hairrig(M,bot['roller'],110,1.1,1,height=.03);installed_hair.parent=root;installed_hair.location=(0,-.2,.03)
   lift_end=t0+.38;turn_end=cue(c,'뒤집',edge='end');move(root,(0,0,.25),(0,0,1.6),t0,lift_end);key(root,'location',turn_end,(0,0,1.6));key(root,'location',t1-.025,(0,0,1.12));linear(root);rotate(root,0,-math.pi,lift_end,turn_end);target=(0,0,.85);camloc=(4,-6,3.4);lens=48
  else:
   
   for ob in [right]+list(right.children_recursive):ob.hide_render=True
   root.location.z=1.0;root.rotation_euler.x=math.pi;r=bot['roller'];embedded_hair,embedded_control=hairrig(M,r,110,1.1,1,height=0);embedded_hair.parent=r['root'];embedded_hair.location=(0,0,0);a=cue(c,'꺼내');b=cue(c,'꺼내','end')+.25;move(r['root'],(0,-.2,.03),(0,-.2,-.75),a,b);h=hand(M,'Hand extracting the brush');h.parent=root;move(h,(1.11,-.2,.03),(1.11,-.2,-.75),a,b);camloc=(2.5,-4.5,4);target=(0,0,1.1);lens=45
  description='손이 본체를 들어 실제 뒤집음' if cutno==2 else '뒤집은 청소기의 브러시 베이에서 롤러를 손으로 꺼냄'
 elif cutno in [3,15,16,17,38,40]:
  r,h,q=rmain(slide=1,count=110);controls(q,'angle',[(t0,1.1*4*math.pi),(t1,1.1*4*math.pi+.7)])
  if cutno==3:camloc=(1.4,3.0,1.45);target=(.95,0,.75);lens=100;description='개별 가닥이 노출 축에 여러 겹 감긴 상태를 낮은 매크로로 관찰'
  elif cutno==15:
   camloc=(-.2,.4,5.5);target=(.1,0,.75);lens=75;description='가닥이 끝단에 남아 있는 상태에서 깨끗한 중앙 브러시가 회전'
  elif cutno in [16,38]:
   a=cue(c,'열어');b=cue(c,'열어','end')+.25
   for side,cap in zip([-1,1],r['caps']):
    old=tuple(cap.location);new=(old[0]+side*.52,0,0);move(cap,old,new,a,b);handroot=hand(M,'Hand removing cap',side<0);handroot.location=(old[0],0,.75);move(handroot,tuple(handroot.location),(new[0],0,.75),a,b)
   camloc=(1,7,3);lens=36;target=(0,0,.75);description='양쪽 캡과 손이 축 방향으로 빠지며 안쪽 베어링 감김을 노출'
  elif cutno==17:
   camloc=(2.8,3,2.1);target=(.91,0,.75);lens=90;right=hand(M,'Hand checking bearing',gap=.11);move(right,(1.45,0,.75),(1.015,0,.75),cue(c,'끝단'),cue(c,'베어링','end'));rotate(r['bearings'][1],0,.8,cue(c,'확인'),cue(c,'확인','end'))
   for cap in r['caps']:
    for ob in [cap]+list(cap.children_recursive):ob.hide_render=True;description='손가락으로 끝단 베어링을 잡고 돌려 상태 확인'
  elif cutno==32:
   controls(q,'wind',[(t0,.4),(t1,1.2)]);camloc=(-2.5,4,3);target=(.85,0,.75);lens=85;description='이미 남은 끝단 다발에 가닥이 추가로 감겨 두께 증가'
  else:
   
   for cap in r['caps']:
    for ob in [cap]+list(cap.children_recursive):ob.hide_render=True
   for o in bpy.data.objects:
    if ('cradle' in o.name) and o.location.x>0:o.hide_render=True
   camloc=(2.6,3.8,2);target=(.88,0,.75);lens=85;sc=scissors(M);sc['root'].location=(.95,.18,.4);operator=hand(M,'Hand operating the scissors',gap=.14);operator.parent=sc['root'];operator.location=(0,0,-.24);operator.rotation_euler=Matrix(((0,0,1),(1,0,0),(0,1,0))).to_euler()
   a=cue(c,'가위');b=cue(c,'잘라');end=cue(c,'잘라','end')
   move(sc['root'],(.95,.35,.4),(.95,.04,.48),a,b)
   for side,blade in zip([-1,1],sc['blades']):rotate(blade,side*.45,0,b,end,1)
   # A real cut opens the wound strand and lets the severed bundle be removed.
   h=sever(h,M,t0,end,relax=True)
   a=cue(c,'빼는');b=cue(c,'빼는','end')+.35;move(h,(0,0,.75),(.55,.6,1.15),a,b);grip=hand(M,'Hand lifting severed hair',gap=.05);move(grip,(1.02,0,.75),(1.57,.6,1.15),a,b)
   move(sc['root'],(.95,.04,.48),(.95,.85,.50),t1-2.0,t1-1.4)
   # Clear the working area after removal, show freely turning clean bearing.
   move(h,(.55,.6,1.15),(1.48,.9,1.5),t1-1.5,t1-1.0);move(grip,(1.57,.6,1.15),(2.5,.9,1.5),t1-1.5,t1-1);controls(q,'angle',[(t0,1.1*4*math.pi),(cue(c,'모터'),1.1*4*math.pi),(t1,1.1*4*math.pi+TAU*2)])
   motor_cue=cue(c,'모터');mot=motor(M);mot['root'].location=(1.85,0,.75);coupling=cylinder('Clean brush drive coupling',(1.20,0,.75),.045,.22,M['black'])
   # A new result shot follows the completed pull; tools and removed fibres
   # stay in the preceding shot rather than obscuring the named motor.
   for tool in [grip,sc['root']]:
    for ob in [tool]+list(tool.children_recursive):
     key(ob,'hide_render',t0,False);key(ob,'hide_render',motor_cue,True);linear(ob)
   key(h,'hide_render',motor_cue,True);linear(h)
   for ob in [mot['root']]+list(mot['root'].children_recursive)+[coupling]:
    key(ob,'hide_render',t0,True);key(ob,'hide_render',motor_cue,False);linear(ob)
   driver=mot['rotor'].driver_add('rotation_euler',0).driver;driver.type='AVERAGE';v=driver.variables.new();v.name='clean_shaft_rotation';v.type='SINGLE_PROP';v.targets[0].id=q;v.targets[0].data_path='["angle"]'
   description='가위가 다발에 접근→힌지가 닫혀 가닥 절단→손이 다발을 빼냄→모터를 발화에 작업 후 연결 모터·정리된 축 구도로 컷 전환→가림 없이 축과 모터가 함께 자유 회전'
 elif cutno==4:
  bot=robot(M);move(bot['root'],(0,.1,.25),(0,-.4,.25),t0,t1);rotate(bot['roller']['spin'],0,TAU,t0,t1);camloc=(3,-4.8,1.6);lens=57;target=(0,0,.2)
  for wheel in bot['wheels']:rotate(wheel,0,2,t0,t1)
  description='정상 녹색 램프가 켜진 청소기가 계속 주행'
 elif cutno in [5,13,21]:
  d=duct(M)
 elif cutno in [6,9,10,11,12,14,22,23,34,36]:
  r,h,q=rmain(wind=0,slide=0,count=90)
  if cutno in [9,10,11,12]:
   controls(q,'wind',[(22,0),(24.4185,0),(24.8987,.08),(26.1992,.08),(28.3001,1.1),(34.2,1.1)])
   controls(q,'angle',[(22,0),(24.4185,0),(24.8987,.08*4*math.pi),(26.1992,.08*4*math.pi),(28.3001,1.1*4*math.pi),(34.2,1.1*4*math.pi+(34.2-28.3001)*TAU)])
   controls(q,'slide',[(22,0),(28.6202,0),(30.0008,.12),(31.2213,.12),(33.0,.96),(33.5,1),(34.2,1)])
   if cutno==9:
    controls(q,'pre_roll',[(22,0),(22.6377,0),(24.4185,TAU),(34.2,TAU)]);d=r['spin'].driver_add('rotation_euler',0).driver;d.type='SUM';v=d.variables.new();v.name='pre_catch_rotation';v.type='SINGLE_PROP';v.targets[0].id=q;v.targets[0].data_path='["pre_roll"]'
    for sec,y in [(22,.06),(24.1784,.06),(24.4185,0),(34.2,0)]:key(h,'location',sec,(0,y,.75))
    linear(h)
   cameras={9:((2,5,2.5),(0,0,.6),45),10:((3.2,3.1,3.2),(.1,0,.75),75),11:((-.2,.8,6.5),(.25,0,.75),75),12:((3,4.2,2.4),(.5,0,.75),62)};camloc,target,lens=cameras[cutno]
   if cutno==12:
    glass=glass_material()
    for o in [r['core']]+r['fins']:o.data.materials.clear();o.data.materials.append(glass)
    r['bristles'].hide_render=True
   description={9:'돌아가면 발화에 스핀들이 먼저 한 바퀴 회전; 모에 발화에 가닥 접근; 걸립니다에 모에 걸려 감김 시작',10:'같은 가닥의 늘어진 자유 길이가 줄어들며 두 바퀴 감김',11:'위에서 본 다발이 중앙에서 끝단 방향으로 떠남',12:'반투명 롤러 바깥에서 다발이 이동한 뒤 노출 축·베어링 홈으로 모임'}[cutno]
  elif cutno==6:
   r['root'].location.z=.245;h.hide_render=True
   for o in bpy.data.objects:
    if 'cradle' in o.name:o.hide_render=True
   controls(q,'angle',[(t0,0),(cue(c,'도는'),0),(t1,TAU*1.5)]);camloc=(2,4,.7);target=(0,0,.24);lens=60
   description='롤러 모 끝이 실제 바닥에 닿은 채 회전'
  elif cutno==14:
   spin(q,.04,1.15,cue(c,'한'),cue(c,'축에','end'));drift(q,cue(c,'축에'),t1-.25,end=.38);camloc=(-2.4,3,3.0);target=(0,0,.75);lens=70;description='긴 가닥이 한 바퀴를 넘게 돌아도 흡입되지 않고 축에 잔류'
  elif cutno==22:
   spin(q,0,1.1,cue(c,'감기기'),cue(c,'회전','end'));done=cue(c,'회전','end');controls(q,'angle',[(done,1.1*4*math.pi),(t1,1.1*4*math.pi+(t1-done)*TAU)]);drift(q,cue(c,'축으로'),cue(c,'밀어','end'));d=duct(M);d.location=(.5,-.45,.9);dirt(M,c,location=(.5,-.45,.85));camloc=(2.5,4.8,2.8);target=(.45,0,.90);lens=52;description='먼지는 위로 이동하지만 긴 가닥은 회전으로 감긴 후 축 끝으로 이동'
  elif cutno==23:
   controls(q,'wind',[(t0,1.1),(t1,1.1)]);controls(q,'slide',[(t0,1),(t1,1)]);controls(q,'angle',[(t0,0),(t1,TAU*1.5)]);d=duct(M);d.location=(.5,-.4,.9);dirt(M,c,n=48,location=(.5,-.4,.8));camloc=(2.5,4.8,2.8);target=(.5,0,.95);lens=60;description='흡입량은 커져도 끝단 다발은 남아 함께 회전'
  else:
   if cutno==30:spin(q,.3,1.1,t0+.2,t1-.2);drift(q,t0+.7,t1-.1,start=.55,end=1)
   elif cutno==34:spin(q,.1,1.1,cue(c,'회전'),cue(c,'머리카락','end'));drift(q,cue(c,'끝단'),cue(c,'미끄러','end'))
   else:spin(q,.12,1.1,cue(c,'회전'),cue(c,'머리카락','end'));drift(q,cue(c,'끝단'),cue(c,'미끄러','end'))
   done=cue(c,'머리카락','end');controls(q,'angle',[(done,1.1*4*math.pi),(t1,1.1*4*math.pi+max(0,t1-done)*TAU)])
   camloc=((-2.4,4,2.2) if cutno==30 else ((-.3,.7,6.5) if cutno==34 else (3.3,4.5,2.2)));target=(.4,0,.75);lens=65
   if cutno==36:
    camloc=(-1.4,-4.5,2.3);target=(.45,0,.75);lens=65
    for ob in [r['caps'][1]]+list(r['caps'][1].children_recursive):ob.hide_render=True
    r['bristles'].hide_render=True
    glass=glass_material()
    for o in [r['core']]+r['fins']:o.data.materials.clear();o.data.materials.append(glass)
   description='회전 중 개별 가닥이 롤러 중앙에서 노출 끝단으로 이동해 남는 원리를 연속 추적'
 elif cutno in [7,8]:
  if cutno==7:
   actual=benchroller(M,'Actual roller before bobbin analogy');rotate(actual['spin'],0,TAU*1.1,t0,t1)
   r=bobbin(M);r['root'].location=(3.4,0,.75)
   for side in [-1,1]:cube('Bobbin spindle support',(3.4+side*.55,0,.35),(.08,.16,.70),M['white'],edge=.025)
   h,q=hairrig(M,r,1,0,0,spread=0);h.location.x=3.4;h.data.attributes['radius'].data.foreach_set('value',[.0022*(.5+.5*math.sin(math.pi*(k+.5)/168)) for k in range(168)]);spin(q,0,.9,cue(c,'실을'),t1-.05);camloc=(2.2,5,2);lens=45;target=(0,0,.75);description='실제 롤러 회전에서 시작해 실을 발화 때 나무 실패로 전환; 실패가 가는 실을 감음'
  else:
   r,h,q=rmain(.6,0);controls(q,'angle',[(t0,0),(t1,TAU*1.4)]);drift(q,cue(c,'축'),cue(c,'밀어','end'));camloc=(-.2,.6,6);target=(.3,0,.75);lens=68;description='위에서 본 가닥 다발이 회전 축 방향으로 이동'
 elif cutno in [18,19]:
  r,h,q=rmain(1.1,1,count=125);mot=motor(M);mot['root'].location=(1.85,0,.75);cylinder('Flexible drive coupling',(1.20,0,.75),.045,.22,M['black'])
  if cutno==18:
   controls(q,'angle',[(t0,0),(t0+.7,TAU),(t1,TAU+1)]);rotate(mot['rotor'],0,TAU*2,t0,t0+.7);rotate(mot['rotor'],TAU*2,TAU*2+1,t0+.7,t1);camloc=(3,5.5,3);target=(1.45,0,.75);lens=62
   hot=mat('Motor load copper heat',(.57,.08,.025),.8,.3);p=hot.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(.7,.025,.001,1);p.inputs['Emission Strength'].default_value=0;p.inputs['Emission Strength'].keyframe_insert('default_value',frame=t0*24+1);p.inputs['Emission Strength'].default_value=.7;p.inputs['Emission Strength'].keyframe_insert('default_value',frame=t1*24+1)
   for o in mot['rotor'].children:
    if 'winding' in o.name:o.data.materials.clear();o.data.materials.append(hot)
   description='끝단 다발에 막혀 회전이 느려지고 연결 모터 권선 온도가 올라감'
  else:
   damage_start=cue(c,'손상');damage_end=cue(c,'손상','end')+.20
   for i,o in enumerate(r['fins']):
    if i in [0,5]:
     o.shape_key_add(name='Undamaged rubber');shape=o.shape_key_add(name='Buckled rubber lip');radii=[math.hypot(v.co.y,v.co.z) for v in o.data.vertices]
     for vertex,point in zip(o.data.vertices,shape.data):point.co=damaged_fin_position(tuple(vertex.co),min(radii),max(radii),r['length'])
     for sec,value in [(t0,0.0),(damage_start,0.0),(damage_end,1.0)]:shape.value=value;shape.keyframe_insert(data_path='value',frame=sec*24+1)
     linear(o.data.shape_keys)
   bend_brush_bristles(r['bristles'],t0,damage_start,damage_end,r['r'],r['length']);camloc=(-2.5,3.5,2.4);target=(.6,0,.75);lens=90;description='손상될 발화에 앞쪽 고무 핀 외곽이 실제 셰이프키로 접히고, 개별 나일론 모가 휘어 손상 상태가 드러남'
 elif cutno==20:
  physical_dial(M,c);camloc=(1.6,2,3);target=(.1,0,.12);lens=85;description='손이 실제 흡입력 조절 다이얼을 돌림'
 elif cutno==24:
  bot=robot(M);root=bot['root'];root.location.z=2.15;root.rotation_euler.x=math.pi
  rr=bot['roller']['root'];move(rr,(0,-.2,.03),(0,-.2,-.85),cue(c,'구조'),t1-.1)
  for i,cap in enumerate(bot['roller']['caps']):move(cap,tuple(cap.location),(cap.location.x+(-.3 if i==0 else .3),0,0),cue(c,'바꿨'),t1-.05)
  mot=motor(M);mot['root'].location=(0,0,.55);camloc=(4,6,3.6);target=(0,0,1.4);lens=45;description='본체 하부·롤러·캡·모터가 실제 간격을 벌리는 분해도'
 elif cutno in [25,26]:
  rs=[]
  for side in [-1,1]:
   r=roller(M,'Left short roller' if side<0 else 'Right short roller',.85,.16,ends=(side,),helical=True);r['root'].location=(side*.5,0,.75);rotate(r['spin'],0,side*TAU*(2 if cutno==25 else 3),t0,t1);rs.append(r)
  
  if cutno==26:d=duct(M);d.location=(0,-.13,.95)
  if cutno==26:
   for side,r in zip([-1,1],rs):
    # Separate curved strands follow helical surface to the central intake gap.
    rng=random.Random(11);splines=[[(side*(.82-.55*k/39)-side*.545,.22*math.cos(k*.15+j*.02),.22*math.sin(k*.15+j*.02)) for k in range(40)] for j in range(32)]
    h=curves('Individual hair transported to central gap',splines,M['hair'],.0008);h.location=(side*.545,0,.75);a=cue(c,'가운데');b=cue(c,'밀어','end');move(h,(side*.545,0,.75),(side*.17,0,.75),a,b);move(h,(side*.17,0,.75),(0,-.13,2.15),cue(c,'빨아'),cue(c,'빨아','end')+.3);scale(h,1,.03,cue(c,'빨아'),t1-.05)
   description='서로 반대로 도는 두 짧은 롤러의 가닥이 중앙 틈에 모인 뒤 흡입관으로 상승'
  else:description='가운데 간격이 있는 짧은 두 롤러가 서로 반대 방향으로 회전'
  camloc=(-.2,.5,6) if cutno==25 else (2.6,5,2.8);target=(0,0,1);lens=65
 elif cutno in [27,28]:
  r,h,q=rmain(.2,0,count=60);comb=cutter_comb(M);comb.location=(0,.24,.48);controls(q,'angle',[(t0,.2*4*math.pi),(t1,.2*4*math.pi+TAU*1.5)])
  if cutno==27:
   spin(q,.2,.65,t0,t1);move(comb,(0,.34,.40),(0,.205,.48),cue(c,'절단'),cue(c,'절단','end'));controls(q,'wind',[(t0,.2),(cue(c,'절단'),.65),(t1,.65)]);pieces=sever(h,M,t0,cue(c,'절단','end'),relax=True,release_duration=.36,release_forward=.24,release_scatter=.12);move(pieces,(0,0,.75),(0,.1,1.4),cue(c,'절단','end'),t1-.1);dirt(M,c,'fur',22,(0,.15,.68));description='촘촘한 금속 절단 빗이 회전 브러시에 접근해 긴 가닥을 끊고 분리된 조각이 풀리며 앞쪽 상승 경로로 흡입'
  else:
   h.hide_render=True;d=duct(M);d.location=(0,.20,.9)
   for ob in d.children:
    if ob.type=='MESH':
     for material in ob.data.materials:
      if material.name.startswith('Clear polycarbonate'):material.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.08
   controls(q,'angle',[(t0,.65*4*math.pi),(t1,.65*4*math.pi+TAU*1.5)]);pieces=dirt(M,c,'fur',72,(0,.18,.63),emission_fraction=.78);move(comb,(0,.205,.48),(0,.205,.48),t0,t1);description='절단된 짧은 조각이 끝단 축으로 가지 않고 중앙 흡입 경로로 상승'
  camloc=(2.3,3,1.9) if cutno==27 else (-2.8,3.6,2.0);target=(0,.1,.75) if cutno==27 else (0,.15,1.0);lens=78 if cutno==27 else 85
 elif cutno in [29,33]:
  r=roller(M,'Conventional full-width comparison roller',1.35,.14);r['root'].location=(0,-.60,.55);h,q=hairrig(M,r,125,1.1,1,height=.55,target=.72,end=.68);h.location.y=-.60;controls(q,'angle',[(t0,0),(t1,TAU)])
  pairs=residual_duo(M,c,16,row=.60,height=.55,length=.60,center=.35)
  if cutno==29:
   drift(q,cue(c,'경로'),cue(c,'바꾼','end'),start=.2,end=1)
   for side in [-1,1]:
    strands=[[(side*(.60-.40*k/35),.60+.21*math.cos(k*.15+j*.06),.55+.21*math.sin(k*.15+j*.06)) for k in range(36)] for j in range(20)];hair=curves('Modified route leads centrally',strands,M['hair'],.001);a=cue(c,'경로');b=cue(c,'바꾼','end');move(hair,(0,0,0),(-side*.27,0,0),a,b)
  camloc=(.2,6,4.2);target=(.3,0,.65);lens=53
  if cutno==33:
   camloc=(1.6,4.6,3.4);target=(.72,0,.55);lens=100
   for cap in r['caps']:
    for ob in [cap]+list(cap.children_recursive):ob.hide_render=True
  description='기존 한 롤러와 개선된 분할 롤러를 함께 비교; 변경 구조에서도 소수의 끝단 가닥을 남겨 한계 표시'
  if cutno==29:
   camloc=(0,.45,6.5);target=(0,.35,.55);lens=55
   for cap in r['caps']:
    for ob in [cap]+list(cap.children_recursive):ob.hide_render=True
   description='위에서 본 분리 비교: 기존 다발은 바깥 끝단으로, 개선된 두 롤러의 가닥은 중앙으로 이동; 두 경로가 다른 행과 겹치지 않음'
 elif cutno in [30,32]:
  pairs=residual_duo(M,c,35 if cutno==30 else 65)
  if cutno==32:
   for r,h,q in pairs:controls(q,'wind',[(t0,.7),(t1,1.1)])
  camloc=(2.6,5,2.4) if cutno==30 else (1.4,3.2,1.5);target=(.96,0,.75);lens=55 if cutno==30 else 105
  description='개선된 짧은 두 롤러가 반대 회전을 계속하지만 바깥 끝단에 잔류 다발이 남음' if cutno==30 else '개선 구조의 노출 끝단에 추가 가닥이 감기며 쌓임'
 elif cutno==35:
  r,h,q=rmain(1.1,1);dial=physical_dial(M,c);dial.location=(.25,.6,.04);dial.scale=(.65,.65,.65);controls(q,'angle',[(t0,0),(t1,TAU*.6)]);camloc=(2.3,5,2.4);target=(.5,0,.65);lens=55;description='흡입력 다이얼을 돌려도 같은 화면의 끝단 감김은 남음'
 elif cutno==31:
  # Grooming context: actual articulated brush through long hair, then pet turns head.
  hairroot=empty('Long hair grooming lock');splines=[]
  for j in range(110):splines.append([(-.7+.006*j,.03*math.sin(j*.3+k*.12),.15+1.2*k/49) for k in range(50)])
  lock=curves('110 separate long hair fibres',splines,M['hair'],.00085,hairroot)
  brush=empty('Grooming brush');cube('Rounded hairbrush cushion',(-.4,0,.8),(.7,.15,.15),M['cloth'],brush,.07);cube('Brush handle',(-.9,0,.8),(.55,.08,.08),M['white'],brush,.035)
  for j in range(10):
   for k in range(3):cylinder('Hairbrush pin',(-.68+j*.06,.06+k*.035,.78),.006,.12,M['bristle'],brush,'Y',8)
  grip=hand(M,'Hand holding grooming brush',mirror=True,gap=.05);grip.parent=brush;grip.location=(-.95,0,.8)
  move(brush,(0,0,.35),(0,0,-.35),cue(c,'긴'),cue(c,'많거나','end'));pet=cat(M);pet['root'].location=(1.1,0,0);rotate(pet['head'],0,.35,cue(c,'반려동물'),t1,2)
  camloc=(3.2,-5,2.5);target=(.25,0,.65);lens=55;description='브러시가 긴 개별 가닥을 빗고 반려동물 발화 때 고양이가 고개를 돌림'
 elif cutno==39:
  cal=calendar(M);p=pencil(M);p.location=(-1.054,.34,1.0);p.rotation_euler.y=.85;grip=hand(M,'Hand writing calendar checks',mirror=True,gap=.06);grip.parent=p;grip.location=(.68,0,0)
  for i,w in enumerate(['한','두']):
   check=cal['checks'][i];key(check.data,'bevel_factor_end',t0,0);a=cue(c,w);b=cue(c,w,'end')+.15;key(check.data,'bevel_factor_end',a,0);key(check.data,'bevel_factor_end',b,1);linear(check.data)
   
   y=.34-i*.68;move(p,(-1.054,y,1.0),(-1.054,y,.883),a-.15,a);key(p,'location',a+(b-a)*.315,(-.974,y-.065,.883));key(p,'location',b,(-.834,y+.11,.883));linear(p)
  haircue=cue(c,'머리카락');liftend=cue(c,'많거나','end')-.05;petcue=cue(c,'반려동물');doublecue=cue(c,'두')
  parts=[[(-.4+.8*k/39,.025*math.sin(j*.73)+.008*math.sin(k*.5+j),.04*math.sin(math.pi*k/39)) for k in range(40)] for j in range(110)]
  sample=curves('Household long hair sample lifted by hand',parts,M['hair'],.0009);sample.location=(-2.4,0,.025);relax_severed_strands(sample,parts,t0,haircue-.035,release_duration=liftend-haircue)
  liftend=cue(c,'많거나','end')-.05;move(sample,(-2.4,0,.025),(-2.4,0,.95),haircue,liftend)
  hairhand=hand(M,'Hand lifting long household hair',mirror=True,gap=.04);move(hairhand,(-2.825,.045,.025),(-2.825,.045,.95),haircue,liftend)
  pet=cat(M);pet['root'].location=(2.4,0,.04);mid=(petcue+doublecue)/2;rotate(pet['head'],0,.15,petcue,mid,1);rotate(pet['head'],.15,0,mid,doublecue,1)
  paw=next(o for o in pet['root'].children if o.name.startswith('Cat front paw'));old=tuple(paw.location);move(paw,old,(old[0],-.33,.13),petcue,mid);move(paw,(old[0],-.33,.13),old,mid,doublecue)
  camloc=(.2,-.8,4);target=(0,0,.15);lens=58;description='한 번에 달력 첫 체크 → 머리카락 발화에 손이 가는 가닥을 들어 올림 → 반려동물 발화에 고양이가 고개와 앞발을 움직임 → 두 번에 달력 두 번째 체크'
 else:raise RuntimeError(cutno)
 # Complete suction cut setup after branch to keep the duct geometry shared.
 if cutno in [5,13,21]:
  mode='fur' if cutno==13 else 'dust';dirt(M,c,mode,40,(0,0,.2));camloc=(2.7,4,1.9) if cutno!=13 else (-2.7,4,1.7);target=(0,0,.7);lens=78;description='짧은 개별 털이 흡입관으로 상승' if cutno==13 else '떠 있는 먼지 입자가 실제 흡입관을 따라 상승'
 
 for o in bpy.data.objects:
  if o.type=='LIGHT' and o.name.startswith('Large'):
   o.location=(-3,4 if camloc[1]>=0 else -4,5);o.data.energy=1100;aim(o,target)
 cam.location=camloc;aim(cam,target);cam.data.lens=lens;focus.location=target;cam.data.dof.aperture_fstop=6
 def camera_cuts(events):
  c['camera_events']=[{'time':when,'position':loc,'target':look,'lens':mm} for when,loc,look,mm in events]
  for when,loc,look,mm in events:
   cam.location=loc;aim(cam,look);cam.data.lens=mm;focus.location=look
   for path in ['location','rotation_euler']:cam.keyframe_insert(data_path=path,frame=when*24+1)
   cam.data.keyframe_insert(data_path='lens',frame=when*24+1);focus.keyframe_insert(data_path='location',frame=when*24+1)
  for obj in [cam,cam.data,focus]:
   for fc in obj.animation_data.action.fcurves:
    for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
 if cutno==40:camera_cuts([(t0,camloc,target,lens),(motor_cue,(3.5,4.8,4.0),(1.45,0,.9),65)])
 if cutno==7:camera_cuts([(t0,(2.2,5,2),(0,0,.75),45),(cue(c,'실을'),(5.3,4.8,1.6),(3.4,0,.70),70)])
 if cutno==16:
  camera_cuts([(t0,(1,7,3),(0,0,.75),36),(cue(c,'머리카락'),(1.5,3.2,1.5),(.97,0,.75),100)]);description+='; 머리카락 발화에서 열린 끝단의 감긴 가닥으로 확대 컷'
 if cutno==39:camera_cuts([(t0,(.2,-.8,4),(0,0,.15),58),(haircue,(-2.1,-3.5,1.6),(-2.65,0,.5),75),(petcue,(3.5,-3.5,1.7),(2.45,-.08,.35),68),(doublecue,(.2,-.8,4),(0,0,.15),58)])
 if cutno==30:
  for when,loc,look,mm in [(t0,(2.6,5,2.4),(.4,0,.75),55),(cue(c,'완벽'),(1.5,3.5,1.6),(.97,0,.75),100)]:
   cam.location=loc;aim(cam,look);cam.data.lens=mm;focus.location=look
   for path in ['location','rotation_euler']:cam.keyframe_insert(data_path=path,frame=when*24+1)
   cam.data.keyframe_insert(data_path='lens',frame=when*24+1);focus.keyframe_insert(data_path='location',frame=when*24+1)
  for obj in [cam,cam.data,focus]:
   for fc in obj.animation_data.action.fcurves:
    for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
 if cutno==31:
  for when,loc,look,mm in [(t0,(-.4,-4.5,1.8),(-.4,0,.75),68),(cue(c,'반려동물'),(2.5,-4.0,1.5),(1.1,-.05,.3),65)]:
   cam.location=loc;aim(cam,look);cam.data.lens=mm;focus.location=look
   for path in ['location','rotation_euler']:cam.keyframe_insert(data_path=path,frame=when*24+1)
   cam.data.keyframe_insert(data_path='lens',frame=when*24+1);focus.keyframe_insert(data_path='location',frame=when*24+1)
  for obj in [cam,cam.data,focus]:
   for fc in obj.animation_data.action.fcurves:
    for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
  description+='; 반려동물 단어에서 고양이 전신 각도로 컷 전환'
 s.frame_start=c['start_frame'];s.frame_end=c['end_frame'];s.frame_set(s.frame_start)
 c['initial_state']='대상과 접촉점이 보이는 실제 3D 상태';c['action']=description;c['end_state']='실제 키프레임 동작의 끝 상태';c['camera']={'position':camloc,'target':target,'lens':lens}
 return s,cam,focus,c
