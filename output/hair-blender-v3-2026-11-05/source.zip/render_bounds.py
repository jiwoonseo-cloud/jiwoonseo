"""Conservative native-pixel geometry AND area-light shadow bounds for 3D caching."""
import bpy,math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

def animated(obj):
 q=obj
 while q:
  if q.animation_data and (q.animation_data.action or len(q.animation_data.drivers)):return True
  q=q.parent
 if obj.type in ['MESH','CURVES','CURVE']:
  for mat in obj.data.materials:
   if mat and mat.node_tree and mat.node_tree.animation_data and mat.node_tree.animation_data.action:return True
 return False

def bounds(scene,cam):
 moving=[o for o in scene.objects if o.type in ['MESH','CURVES','CURVE'] and animated(o)];lights=[o for o in scene.objects if o.type=='LIGHT' and o.data.use_shadow]
 xmin,ymin,xmax,ymax=1.,1.,0.,0.
 def include(p):
  nonlocal xmin,ymin,xmax,ymax
  v=world_to_camera_view(scene,cam,p)
  if v.z<=.02:return
  xmin=min(xmin,v.x);xmax=max(xmax,v.x);ymin=min(ymin,v.y);ymax=max(ymax,v.y)
 for frame in range(scene.frame_start,scene.frame_end+1):
  scene.frame_set(frame);deps=bpy.context.evaluated_depsgraph_get()
  for orig in moving:
   if orig.hide_render:continue
   o=orig.evaluated_get(deps);corners=[o.matrix_world@Vector(v) for v in o.bound_box]
   # Hair Curves bounds in Blender 4.3 are evaluated after Geometry Nodes.
   if o.type=='CURVES' and all(tuple(v)==(-1,-1,-1) for v in o.bound_box):
    pts=o.data.attributes['position'].data;mn=[min(p.vector[k] for p in pts) for k in range(3)];mx=[max(p.vector[k] for p in pts) for k in range(3)];corners=[o.matrix_world@Vector((x,y,z)) for x in [mn[0],mx[0]] for y in [mn[1],mx[1]] for z in [mn[2],mx[2]]]
   for p in corners:
    include(p)
    if p.z>0:
     for light in lights:
      basis=light.matrix_world.to_3x3();half=light.data.size*.55
      for u,v in [(-1,-1),(-1,1),(1,-1),(1,1)]:
       l=light.location+basis.col[0]*(u*half)+basis.col[1]*(v*half)
       if l.z>p.z+.03:include(p+(p-l)*(p.z/(l.z-p.z)))
 # 96px extra covers DOF radius, filtering, curved fibre thickness and area edges.
 pad_x,pad_y=96/1080,96/1920
 xmin=max(0,math.floor((xmin-pad_x)*1080/8)*8/1080);xmax=min(1,math.ceil((xmax+pad_x)*1080/8)*8/1080)
 ymin=max(0,math.floor((ymin-pad_y)*1920/8)*8/1920);ymax=min(1,math.ceil((ymax+pad_y)*1920/8)*8/1920)
 scene.frame_set(scene.frame_start)
 if xmax<=xmin or ymax<=ymin:return (0,0,1,1)
 return (xmin,ymin,xmax,ymax)
