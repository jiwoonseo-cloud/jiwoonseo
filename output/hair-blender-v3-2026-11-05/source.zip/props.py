from assets import *
def wood(name='Warm oak'):
 m=mat(name,(.24,.12,.045),0,.39);n=m.node_tree.nodes;p=n.get('Principled BSDF')
 tc=n.new('ShaderNodeTexCoord');v=n.new('ShaderNodeVectorMath');v.operation='MULTIPLY';v.inputs[1].default_value=(2,65,3)
 tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=3;tex.inputs['Detail'].default_value=2
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.22;ramp.color_ramp.elements[0].color=(.12,.052,.018,1);ramp.color_ramp.elements[1].position=.78;ramp.color_ramp.elements[1].color=(.42,.25,.10,1)
 l=m.node_tree.links;l.new(tc.outputs['Generated'],v.inputs[0]);l.new(v.outputs[0],tex.inputs['Vector']);l.new(tex.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],p.inputs['Base Color']);return m
def robot(M):
 root=empty('MASTER white circular robot vacuum')
 lathe('Sculpted ABS chassis shoulder',[(.05,1.13),(.04,1.26),(.07,1.32),(.16,1.35),(.30,1.34),(.35,1.30),(.37,1.22),(.37,.02)],M['white'],root,'Z',96)
 lathe('Separate satin top lid seam',[(.372,.02),(.372,1.20),(.38,1.22),(.389,1.16),(.389,.02)],M['white'],root,'Z',96)
 lathe('Compliant bumper band',[(.07,1.323),(.085,1.354),(.20,1.354),(.225,1.335)],M['black'],root,'Z',96)
 lathe('Lidar turret moulding',[(.38,.15),(.40,.21),(.46,.21),(.48,.18),(.48,.02)],M['white'],root,'Z',48)
 lathe('Lidar optical black window',[(.425,.211),(.453,.211)],M['seal'],root,'Z',48)
 cylinder('Lidar top optical cap',(0,0,.484),.168,.012,M['black'],root,'Z')
 cube('Front depth camera glass',(0,-1.335,.15),(.49,.04,.105),M['seal'],root,.035)
 for x in [-.15,.15]:sphere('Front optical sensor',(x,-1.362,.16),(.027,.014,.027),M['polished'],root)
 ledmat=mat('Green status lamp',(.03,.40,.10),0,.25);p=ledmat.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(.04,.7,.12,1);p.inputs['Emission Strength'].default_value=1
 led=cube('Physical green status lamp',(.34,-.55,.399),(.11,.038,.012),ledmat,root,.015)
 underside=cylinder('Recessed underside ABS plate',(0,0,.105),1.22,.05,M['black'],root,'Z',64)
 cube('Main brush access bay',(0,-.2,.064),(2.09,.70,.11),M['seal'],root,.08)
 embedded=roller(M,'Robot installed main roller',1.8,.16,root);embedded['root'].location=(0,-.2,.03)
 wheels=[]
 for side in [-1,1]:
  x=side*1.03;wheel=empty('Actual drive wheel',root);wheel.location=(x,.2,.04);wheels.append(wheel);cylinder('Wheel tyre',(0,0,0),.25,.20,M['rubber'],wheel,'X');cylinder('Wheel rim',(side*.102,0,0),.145,.014,M['metal'],wheel,'X')
  for j in range(24):
   a=TAU*j/24;o=cube('Wheel traction tread',(0,.252*math.cos(a),.252*math.sin(a)),(.18,.023,.025),M['black'],wheel,.005);o.rotation_euler.x=a
 for j in range(8):
  a=TAU*j/8;cylinder('Underside service screw',(.94*math.cos(a),.94*math.sin(a),.072),.025,.009,M['metal'],root,'Z',12)
  for axis in [0,1]:
   o=cube('Screw recess',(.94*math.cos(a),.94*math.sin(a),.065),(.028,.005,.003),M['black'],root,.001);o.rotation_euler.z=axis*math.pi/2
 for j in range(7):
  a=.4+j*.09;c=cube('Rear exhaust slot',(1.342*math.cos(a),1.342*math.sin(a),.25),(.008,.057,.025),M['black'],root,.006);c.rotation_euler.z=a
 return {'root':root,'roller':embedded,'led':led,'ledmat':ledmat,'wheels':wheels}
def bone(name,a,b,r,M,parent):
 a,b=Vector(a),Vector(b);o=cylinder(name,(a+b)/2,r,(b-a).length,M,parent,'Z',16);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
 for p in [a,b]:sphere(name+' rounded joint',p,(r,r,r),M,parent,16)
def hand(M,name='Right anatomical pinch hand',mirror=False,gap=.175):
 root=empty(name)
 sphere('Palm thenar contour',(.34,.015,0),(.23,.095,.145),M['skin'],root)
 sphere('Thumb thenar pad',(.22,-.01,-.06),(.13,.10,.10),M['skin'],root)
 sphere('Wrist',(.60,.025,-.025),(.18,.075,.09),M['skin'],root)
 chains=[[(.23,.01,.09),(.11,-.005,gap+.01),(-.025,-.005,gap)],[(.25,-.07,-.06),(.12,-.06,-gap),(-.03,-.005,-gap)],[(.31,.08,.08),(.20,.12,.13),(.12,.11,.07)],[(.39,.085,.045),(.28,.13,.10),(.20,.12,.035)],[(.46,.08,0),(.38,.125,.06),(.30,.115,.015)]]
 for j,chain in enumerate(chains):
  for k in range(len(chain)-1):bone('Finger phalanx',chain[k],chain[k+1],.038 if j<2 else .032,M['skin'],root)
 children=[o for o in root.children if o.type=='MESH'];bpy.ops.object.select_all(action='DESELECT')
 for o in children:o.select_set(True)
 bpy.context.view_layer.objects.active=children[0];bpy.ops.object.join();skin=bpy.context.object;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 
 for md in list(skin.modifiers):skin.modifiers.remove(md)
 rem=skin.modifiers.new('Unified organic hand surface','REMESH');rem.mode='VOXEL';rem.voxel_size=.015;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name)
 sm=skin.modifiers.new('Skin surface relaxation','SMOOTH');sm.factor=.65;sm.iterations=4
 for name,loc,scale in [('Index fingernail',(-.01,-.025,gap+.031),(.064,.026,.009)),('Thumb fingernail',(-.015,-.036,-gap-.022),(.055,.027,.008))]:sphere(name,loc,scale,M['nail'],root,20)
 for x,z in [(.08,.173),(.16,-.165)]:curves('Fine knuckle crease',[[(x,-.035,z),(x+.008,0,z+.004),(x,.03,z)]],M['skin'],.001,root)
 cuff=cube('Stitched cotton cuff',(.77,.025,-.035),(.24,.19,.22),M['cloth'],root,.045)
 for side in [-1,1]:curves('Cuff stitched seam',[[((.68+.20*j/12),side*.097,-.10) for j in range(13)]],M['black'],.001,root)
 if mirror:root.scale.x=-1
 return root
def glass_material():
 m=mat('Clear polycarbonate explanatory cutaway',(.28,.49,.55),0,.16);p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Alpha'].default_value=.18;m.surface_render_method='BLENDED';return m
def duct(M):
 root=empty('Transparent intake and dust chamber');glass=glass_material()
 lathe('Transparent intake wall',[(.12,.18),(.16,.23),(.22,.21),(.32,.15),(1.02,.15),(1.08,.20)],glass,root,'Z',48)
 cylinder('Upper collection chamber',(0,0,1.20),.30,.45,glass,root,'Z',48)
 for z,r in [(.15,.22),(1.04,.18),(1.44,.30)]:lathe('Duct retaining collar',[(z-.018,r),(z+.018,r)],M['metal'],root,'Z',40)
 return root
def bobbin(M):
 root=empty('Wooden sewing bobbin');spin=empty('Bobbin rotation spindle',root);oak=wood('Bobbin endgrain')
 lathe('Contoured bobbin flanges and barrel',[(-.46,.025),(-.46,.28),(-.43,.32),(-.38,.33),(-.34,.29),(-.32,.205),(.32,.205),(.34,.29),(.38,.33),(.43,.32),(.46,.28),(.46,.025)],oak,spin,seg=64)
 cylinder('Bobbin brass spindle',(0,0,0),.033,1.24,M['metal'],spin)
 for x in [-.53,.53]:lathe('Bobbin lock washer',[(-.02,.035),(-.02,.09),(.02,.09),(.02,.035)],M['metal'],spin,seg=32).location.x=x
 return {'root':root,'spin':spin}
def pencil(M):
 root=empty('Hexagonal wood pencil');paint=mat('Pencil warm ochre lacquer',(.62,.26,.045),0,.24)
 cylinder('Hexagonal lacquered pencil barrel',(0,0,0),.058,1.45,paint,root,'X',6)
 tip=lathe('Exposed sharpened cedar',[(.72,.058),(.92,.009)],wood('Sharpened cedar'),root,seg=24)
 lathe('Graphite writing point',[(.90,.012),(.96,.002)],M['black'],root,seg=20)
 cylinder('Pencil ferrule',(-.75,0,0),.059,.15,M['metal'],root)
 eraser=mat('Pencil eraser',(.47,.16,.13),0,.75);cylinder('Eraser',(-.88,0,0),.056,.12,eraser,root)
 return root
def calendar(M):
 root=empty('Blank physical maintenance calendar');paper=mat('Warm white paper',(.81,.79,.72),0,.82)
 cube('Calendar backing',(0,0,.05),(1.5,1.8,.08),M['seal'],root,.07)
 for j in range(9):cube('Separate paper page',(0,-j*.002,.10+j*.006),(1.37,1.64,.006),paper,root,.015)
 for j in range(10):
  x=-.59+j*.13;curves('Spiral binding',[[ (x,.76+.045*math.cos(TAU*k/32),.17+.045*math.sin(TAU*k/32)) for k in range(33)]],M['metal'],.008,root)
 checks=[]
 for y in [.34,-.34]:
  curves('Empty checkbox',[[(-.45,y-.12,.159),(-.21,y-.12,.159),(-.21,y+.12,.159),(-.45,y+.12,.159),(-.45,y-.12,.159)]],M['black'],.004,root)
  check=curves('Drawn maintenance check',[[(-.42,y,.162),(-.34,y-.065,.162),(-.20,y+.11,.162)]],M['fin'],.006,root);checks.append(check)
 return {'root':root,'checks':checks}
def cat(M):
 root=empty('Domestic cat on sofa');fur=mat('Cat warm cream fur',(.64,.51,.34),0,.78);dark=mat('Cat tabby markings',(.13,.08,.04),0,.8)
 body=sphere('Cat relaxed torso',(0,0,.21),(.53,.25,.25),fur,root,32)
 head=empty('Cat head motion',root);head.location=(.35,-.10,.41)
 sphere('Cat rounded face',(0,0,0),(.20,.16,.19),fur,head,32)
 for side in [-1,1]:
  v=[(side*.09,-.04,.10),(side*.20,.01,.27),(side*.18,.09,.10),(side*.09,.07,.10)];o=mesh('Rounded pointed cat ear',v,[(0,1,2),(0,2,3),(0,3,1),(1,3,2)],fur,head);bevel(o,.02,3)
  sphere('Cat eye',(side*.075,-.149,.025),(.041,.02,.038),M['fin'],head);sphere('Cat pupil',(side*.075,-.167,.025),(.012,.007,.033),M['black'],head)
  sphere('Cat muzzle',(side*.05,-.154,-.065),(.063,.034,.048),fur,head)
  for j in range(4):curves('Fine cat whisker',[[ (side*.05,-.18,-.045-j*.006),(side*.18,-.20,-.03+j*.01),(side*.28,-.19,-.015+j*.014)]],M['bristle'],.0008,head)
  sphere('Cat front paw',(side*.18,-.20,.06),(.16,.11,.07),fur,root)
 sphere('Cat nose',(0,-.19,-.045),(.025,.014,.018),M['black'],head)
 curves('Curled cat tail',[[(-.4,0,.16),(-.63,-.1,.10),(-.6,-.35,.09),(-.32,-.4,.10)]],dark,.065,root)
 rng=random.Random(421);strands=[]
 for j in range(850):
  a=rng.uniform(0,TAU);u=rng.uniform(-.95,.95);r=math.sqrt(1-u*u);x=.5*u;y=.25*r*math.cos(a);z=.21+.25*r*math.sin(a);normal=Vector((u,r*math.cos(a),r*math.sin(a)))
  p=Vector((x,y,z));q=p+normal*.018;strands.append([p,q])
 curves('850 separate short fur fibres',strands,fur,.0007,root)
 return {'root':root,'head':head}
def scissors(M):
 root=empty('Machined scissors');blades=[]
 for side in [-1,1]:
  b=empty('Scissor blade hinge',root);b.location.y=side*.007
  v=[(-.027,0,-.06),(.045,0,.03),(.014,0,.40),(-.012,0,.45),(-.021,0,.36),(-.033,0,.02)]
  verts=[(side*x,y+dy,z) for dy in [-.006,.006] for x,y,z in v];faces=[tuple(range(6)),tuple(range(11,5,-1))]+[(j,(j+1)%6,(j+1)%6+6,j+6) for j in range(6)]
  o=mesh('Tempered tapered cutting blade',verts,faces,M['metal'],b);bevel(o,.004,2)
  loop=[]
  for k in range(65):a=TAU*k/64;loop.append((-side*.095+.070*math.cos(a),0,-.24+.13*math.sin(a)))
  curves('Oval comfort handle loop',[loop],M['cloth'],.025,b)
  cube('Steel handle shank',(-side*.045,0,-.10),(.035,.022,.19),M['metal'],b,.01)
  blades.append(b)
 cylinder('Scissor pivot bolt',(0,-.018,0),.037,.04,M['polished'],root,'Y',32)
 cube('Pivot screw slot',(0,-.041,0),(.04,.004,.006),M['black'],root,.001)
 return {'root':root,'blades':blades}
def cutter_comb(M):
 root=empty('Anti-tangle cutter comb');cube('Stainless comb spine',(0,0,0),(1.55,.075,.07),M['metal'],root,.015)
 for j in range(22):
  x=-.735+j*.07
  v=[(x-.022,0,0),(x+.022,0,0),(x+.014,0,.23),(x-.012,0,.27),(x-.022,-.024,0),(x+.022,-.024,0),(x+.014,-.008,.23),(x-.012,-.008,.27)]
  o=mesh('Precision comb tooth',v,[(0,1,2,3),(7,6,5,4),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)],M['polished'],root);bevel(o,.002,1)
 for x in [-.65,.65]:cylinder('Comb mounting screw',(x,-.05,-.005),.025,.012,M['black'],root,'Y',16)
 return root
def motor(M):
 root=empty('Detailed cutaway motor');rotor=empty('Motor armature',root)
 lathe('Open metal motor casing',[(-.38,.20),(-.38,.30),(.38,.30),(.38,.20)],M['metal'],root,seg=48,start=1.0,end=TAU-.6)
 cylinder('Armature shaft',(0,0,0),.042,1.15,M['polished'],rotor)
 cylinder('Laminated armature',(0,0,0),.14,.62,M['black'],rotor)
 for a in [0,TAU/3,2*TAU/3]:
  for j in range(13):
   x=-.29+j*.045;coords=[]
   for k in range(33):
    t=TAU*k/32;coords.append((x,.19*math.cos(a)+.067*math.cos(t)*math.cos(a),.19*math.sin(a)+.067*math.cos(t)*math.sin(a)+.042*math.sin(t)))
   curves('Individual copper winding turn',[coords],M['copper'],.006,rotor)
 for side in [-1,1]:lathe('Motor bearing end bell',[(-.025,.04),(-.025,.22),(.025,.22),(.025,.04)],M['metal'],root,seg=32).location.x=side*.4
 return {'root':root,'rotor':rotor}
def room(M):
 root=empty('Real living room');oak=wood();fabric=mat('Sofa woven teal textile',(.026,.095,.11),0,.88,.003)
 for j in range(44):cube('Individual oak floor board',(0,-5+j*.24,-.245),(14,.234,.07),oak,root,.008)
 cube('Plaster wall',(0,4.5,2.0),(14,.14,4.5),M['white'],root,.02)
 cube('Sofa plinth',(0,2.5,.22),(3.6,1.12,.33),M['black'],root,.06)
 for x in [-.88,.88]:
  cube('Sofa seat cushion',(x,2.35,.55),(1.70,1.02,.30),fabric,root,.14)
  cube('Sofa upholstered back',(x,2.87,1.0),(1.75,.28,.85),fabric,root,.14)
 for x in [-1.88,1.88]:cube('Sofa arm',(x,2.5,.76),(.30,1.28,.65),fabric,root,.10)
 for x in [-1.65,1.65]:
  for y in [2.1,2.9]:cylinder('Sofa leg',(x,y,.03),.055,.28,M['black'],root,'Z',20)
 for x in [-3.0,3.0]:
  cylinder('Plant ceramic pot',(x,3,.25),.28,.5,M['white'],root,'Z',32)
  for j in range(12):
   a=TAU*j/12;coords=[(x,3,.48),(x+.18*math.cos(a),3+.18*math.sin(a),.9),(x+.45*math.cos(a),3+.45*math.sin(a),1.5)];curves('Plant leaf stem',[coords],M['fin'],.008,root)
   v=[];f=[]
   for k in range(9):
    u=k/8;cx=x+(.12+.37*u)*math.cos(a);cy=3+(.12+.37*u)*math.sin(a);cz=.83+.62*u+.07*math.sin(math.pi*u);w=.11*math.sin(math.pi*u)
    for side in [-1,1]:v.append((cx+side*w*math.sin(a),cy-side*w*math.cos(a),cz-.025*math.sin(math.pi*u)))
   for k in range(8):f.append((2*k,2*k+1,2*k+3,2*k+2))
   mesh('Tapered curved green leaf',v,f,M['fin'],root)
 return root
