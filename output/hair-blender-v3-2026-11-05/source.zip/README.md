# Blender 3D 제작 원본

Blender 4.3.2, EEVEE, native Hair Curves / Geometry Nodes. 이미지나 동영상 텍스처를 물체 대신 움직인 프로젝트가 아닙니다.

## 컷을 바로 열기

`blends/cut_01.blend`부터 `cut_40.blend`까지 각각 독립적인 장면입니다. 저장된 재생 범위는 원음의 전역 24fps 타임라인입니다. 키프레임·가닥 리그·재질·조명·카메라가 내장되어 있고 Python 프레임 콜백 없이 움직입니다. 외부 이미지/HDRI가 필요 없습니다. `.blend`가 납품 프레임에 사용된 컷별 원본입니다.

예시: `blender -b blends/cut_10.blend -o ./frames/cut10_##### -a`

컷별 파일은 전체 1080×1920 프레임 렌더로 저장했습니다. 최종 제작의 고정 배경 캐시 최적화 없이도 전체 장면을 렌더할 수 있습니다. 렌더 해상도를 낮춘 프레임이나 보간 프레임은 원본으로 사용하지 않았습니다.

## 생성 스크립트

`assets.py`, `props.py`, `hair_nodes.py`, `full_scene.py`가 모델링·재질·native 키프레임을 만듭니다. `plan.json`, `words.json`은 원음의 단어 시간과 컷 범위입니다. `render_full.py`는 40컷의 모든 24fps 동작 상태를 렌더하고, 고정 배경만 캐시할 때 물체 및 면광원 그림자 범위를 모든 프레임에서 계산합니다. 카메라 전환 장면은 전체 프레임을 렌더합니다.

`blender -b --factory-startup --python render_full.py`

환경 변수 `CUT_START` / `CUT_END`로 범위를 제한할 수 있습니다. `assemble.py`는 PNG, 내장 원음/마스터, 단어 자막을 합칩니다. FFmpeg와 requirements.txt의 패키지가 필요합니다. 후처리는 고정 배경의64픽셀 경계 완화·공간 노이즈 정리·소량의 안티앨리어싱·자막이며 프레임 보간, 반복, 배속은 없습니다.

`python assemble.py`

## 검수용 시험 구간

`review/trial_10s.mp4`는 감김·끝단 이동 10초 시험입니다. 함께 든 1초·0.25초 프레임 모음으로 확인했습니다. 최종 완성 영상은 압축파일 바깥의 `hair_pixel.mp4`입니다.

## 음성·강제 정렬

`narration.wav`는 속도를 바꾸지 않은 한국어 원음입니다. `mixed_master.wav`는 조용한 자체 합성 음악/효과음과 음량 보정을 적용한 최종 마스터이며 48kHz,143.125초입니다. 음성 앞·뒤의 에너지 경계를 원음과 비교했을 때 10ms 분석 단위에서 밀림은 0ms였습니다.

`voice.py`와 `align.py`는 실제 생성·정렬 과정 기록입니다. Supertonic3 / MMS 음향 모델 등 공개 모델과 별도 패키지가 필요하므로 압축파일에 대형 모델이나 실행 환경을 넣지 않았습니다. 경로는 제작 당시 기록입니다. 렌더와 편집에는 포함된 WAV/JSON만 있으면 됩니다.

실물 제품 CAD나 완전한 마찰·탄성 시뮬레이션이 아닌 원리 설명용 CGI입니다. 가닥 수 비교는 성능 실험의 수치가 아닙니다. 사실 고지와 제한은 납품 report.md를 확인하세요.
