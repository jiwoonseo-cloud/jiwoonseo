import bpy,math,random
from mathutils import Vector
TAU=2*math.pi
def empty(name,parent=None):
 o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);o.parent=parent;return o
def mat(name,color,metal=0,rough=.4,bump=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if bump:
  tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=260;tex.inputs['Detail'].default_value=2
  b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.16;b.inputs['Distance'].default_value=bump;m.node_tree.links.new(tex.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
def materials():
 return {'white':mat('Satin injection-moulded ivory ABS',(.77,.79,.78),0,.24,.0006),'black':mat('Textured charcoal ABS',(.018,.024,.03),0,.38,.0005),'rubber':mat('Graphite elastomer',(.14,.18,.20),0,.5,.001),'fin':mat('Moulded teal rubber fins',(.08,.28,.29),0,.4,.0005),'accent':mat('Terracotta elastomer index fin',(.36,.085,.045),0,.44,.0004),'metal':mat('Brushed stainless steel',(.47,.54,.60),1,.21,.00025),'polished':mat('Polished bearing steel',(.61,.65,.7),1,.11),'seal':mat('Dark blue nitrile seal',(.025,.06,.09),0,.48),'hair':mat('Individual dark brown hair',(.012,.008,.006),0,.42),'bristle':mat('Nylon bristle filaments',(.64,.59,.46),0,.38),'floor':mat('Soft neutral studio surface',(.34,.38,.41),0,.48,.0004),'copper':mat('Varnished copper winding',(.57,.19,.055),.82,.24),'skin':mat('Skin',(.61,.35,.23),0,.43,.00025),'nail':mat('Natural translucent nail',(.74,.53,.43),0,.29),'cloth':mat('Teal cotton cuff',(.025,.09,.11),0,.8,.001)}
def finish(o,name,m,parent=None):
 o.name=name
 if m:o.data.materials.append(m)
 o.parent=parent
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=True
 return o
def mesh(name,verts,faces,m,parent=None):
 d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update();o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);return finish(o,name,m,parent)
def bevel(o,width=.02,segments=3):
 b=o.modifiers.new('Manufactured edge radii','BEVEL');b.width=width;b.segments=segments
 n=o.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL');return o
def cube(name,loc,scale,m,parent=None,edge=.02):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);finish(o,name,m,parent);bevel(o,edge);return o
def sphere(name,loc,scale,m,parent=None,seg=20):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=seg,ring_count=12,location=loc);o=bpy.context.object;o.scale=scale;return finish(o,name,m,parent)
def cylinder(name,loc,radius,depth,m,parent=None,axis='X',verts=48):
 bpy.ops.mesh.primitive_cylinder_add(vertices=verts,radius=radius,depth=depth,location=loc);o=bpy.context.object
 if axis=='X':o.rotation_euler[1]=math.pi/2
 if axis=='Y':o.rotation_euler[0]=math.pi/2
 finish(o,name,m,parent);bevel(o,min(.012,radius*.08),2);return o
def lathe(name,profile,m,parent=None,axis='X',seg=64,start=0,end=TAU):
 v=[];f=[]
 for x,r in profile:
  for j in range(seg+1):
   a=start+(end-start)*j/seg
   p=(x,r*math.cos(a),r*math.sin(a)) if axis=='X' else (r*math.cos(a),r*math.sin(a),x)
   v.append(p)
 for i in range(len(profile)-1):
  for j in range(seg):a=i*(seg+1)+j;f.append((a,a+1,a+seg+2,a+seg+1))
 return mesh(name,v,f,m,parent)
def curves(name,splines,m,radius=.001,parent=None):
 if radius<=.003:
  c=bpy.data.hair_curves.new(name);c.add_curves([len(s) for s in splines])
  flat=[v for s in splines for p in s for v in p]
  c.attributes['position'].data.foreach_set('vector',flat)
  rad=c.attributes.get('radius') or c.attributes.new('radius','FLOAT','POINT')
  rad.data.foreach_set('value',[radius*(.5+.5*math.sin(math.pi*(j+.5)/len(s))) for s in splines for j in range(len(s))])
  o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);c.materials.append(m);o.parent=parent;o['strand_count']=len(splines);return o
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=1;c.bevel_depth=radius;c.bevel_resolution=0;c.resolution_u=1
 for coords in splines:
  s=c.splines.new('POLY');s.points.add(len(coords)-1)
  for j,(p,co) in enumerate(zip(s.points,coords)):p.co=(*co,1);p.radius=.5+.5*math.sin(math.pi*(j+.5)/len(coords))
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(m);o.parent=parent;return o
def ring(name,x,r,thick,m,parent=None):
 return curves(name,[[(x,r*math.cos(TAU*j/64),r*math.sin(TAU*j/64)) for j in range(65)]],m,thick,parent)
def roller(M,name='Roller',length=1.8,r=.16,parent=None,ends=(-1,1),helical=False):
 root=empty(name,parent);spin=empty(name+' actual rotating spindle',root)
 core=lathe(name+' stepped rubber core',[(-length/2,.035),(-length/2,.14),(-length/2+.018,r),(length/2-.018,r),(length/2,.14),(length/2,.035)],M['rubber'],spin)
 fins=[]
 for rib in range(6):
  v=[];f=[]
  for j in range(49):
   x=-length/2+.025+(length-.05)*j/48;a=TAU*rib/6+2.15*(x if helical else abs(x))/length
   for rad,offset in [(r-.004,-.018),(r+.043,-.008),(r+.043,.008),(r-.004,.018)]:v.append((x,rad*math.cos(a+offset),rad*math.sin(a+offset)))
  for j in range(48):
   for k in range(4):a=j*4+k;b=j*4+(k+1)%4;f.append((a,b,b+4,a+4))
  fins.append(mesh(name+f' helical moulded fin {rib}',v,f,M['accent'] if rib==0 else M['fin'],spin))
 rng=random.Random(83);fibres=[]
 for rib in range(6):
  for j in range(24):
   x=-length/2+.04+(length-.08)*j/23;a=TAU*rib/6+2.15*(x if helical else abs(x))/length+.035
   for k in range(3):
    xx=x+rng.uniform(-.009,.009);aa=a+rng.uniform(-.025,.025);rr=r+.041
    fibres.append([(xx,rr*math.cos(aa),rr*math.sin(aa)),(xx+.002,(rr+.019)*math.cos(aa+.015),(rr+.019)*math.sin(aa+.015)),(xx+.003,(rr+.039)*math.cos(aa+.025),(rr+.039)*math.sin(aa+.025))])
 brush=curves(name+' 432 individual nylon bristle fibres',fibres,M['bristle'],.0011,spin)
 shaft=cylinder(name+' machined axle',(0 if len(ends)==2 else ends[0]*.10,0,0),.034,length+(.43 if len(ends)==2 else .23),M['metal'],spin)
 caps=[];bearings=[]
 for side in ends:
  x=side*(length/2+.115);bearing=empty(name+f' bearing {side}',root);bearing.location.x=x
  lathe(name+' bearing outer race',[(-.025,.05),(-.025,.098),(-.015,.108),(.015,.108),(.025,.098),(.025,.05)],M['metal'],bearing,seg=48)
  ring(name+' bearing inner polished race',-.025,.053,.006,M['polished'],bearing)
  for j in range(9):
   a=TAU*j/9;sphere('Individual bearing ball',(-.027,.078*math.cos(a),.078*math.sin(a)),(.013,.013,.013),M['polished'],bearing,seg=12)
  bearings.append(bearing)
  cap=empty(name+f' removable end cap {side}',root);cap.location.x=side*(length/2+.21)
  lathe('Profiled moulded cap',[(-.045,.039),(-.045,.115),(-.035,.137),(-.015,.145),(.025,.145),(.042,.126),(.045,.039)],M['black'],cap,seg=48)
  ring('Cap dust seal',-.045,.118,.008,M['seal'],cap)
  for j in range(16):
   a=TAU*j/16;ridge=cube('Cap finger grip rib',(0,.145*math.cos(a),.145*math.sin(a)),(.045,.009,.015),M['black'],cap,.003);ridge.rotation_euler[0]=a
  caps.append(cap)
 return {'root':root,'spin':spin,'fins':fins,'core':core,'bristles':brush,'caps':caps,'bearings':bearings,'r':r,'length':length}
def hair_points(t,j=0,wind=1,slide=0,total=2.6,n=168,r=.205,angle=None,height=.75):
 # A continuous strand: an anchored tip rotates with the actual spindle, the
 # remaining free length is tangent to the contact point, and shortens as wound.
 theta0=0;phi=(wind*4*math.pi if angle is None else angle)+.13*math.sin(j*1.7);wound=min(total,wind*4*math.pi*r)
 drift=slide*(.945+.012*math.sin(j*2.1));xbase=.18*math.sin(j*1.71)*(1-slide)+drift
 contraction=max(0,min(1,(xbase-.905)/.04));contraction=contraction*contraction*(3-2*contraction)
 radius=r*(1-contraction)+.047*contraction+.0005*(j%6);out=[]
 for k in range(n):
  s=total*k/(n-1)
  if s<=wound:
   a=theta0+phi-s/max(radius,.035);x=xbase+.025*s/TAU
   out.append((x,radius*math.cos(a),radius*math.sin(a)))
  else:
   q=s-wound;a=theta0+phi-wound/max(radius,.035);cy=radius*math.cos(a);cz=radius*math.sin(a)
   x=xbase+.025*wound/TAU+.025*(math.sin(q*4+j)-math.sin(j))*(1-math.exp(-q/.05))
   drop=max(0,height+cz);out.append((x,cy+max(0,q-drop),cz-min(q,drop)))
 return out
def make_hair(M,count=90):
 strands=[hair_points(0,j,1,0,2.0+(j%11)*.065) for j in range(count)]
 return curves('HAIR 90 separate thin curves',strands,M['hair'],.0010)
def aim(o,target):o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
def setup(engine='BLENDER_EEVEE_NEXT',samples=12):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);bpy.data.orphans_purge(do_recursive=True)
 s=bpy.context.scene;s.render.engine=engine;s.render.resolution_x=1080;s.render.resolution_y=1920;s.render.resolution_percentage=100;s.render.fps=24;s.render.image_settings.file_format='PNG';s.render.film_transparent=False
 s.render.threads_mode='FIXED';s.render.threads=4;s.render.use_persistent_data=True
 s.world.color=(.18,.18,.18);s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.24,.27,.30,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.45
 if engine=='BLENDER_EEVEE_NEXT':
  s.eevee.taa_render_samples=samples;s.eevee.use_raytracing=False;s.eevee.use_gtao=True;s.eevee.gtao_distance=3;s.eevee.shadow_resolution_scale=.5
 else:s.cycles.samples=samples;s.cycles.use_denoising=False;s.cycles.max_bounces=3;s.cycles.transparent_max_bounces=4
 s.view_settings.view_transform='AgX'
 for name,loc,power,size,col in [('Large softbox key',(-3,-4,5),650,4,(1,.91,.80)),('Cool fill',(4,1,3),350,3,(.75,.87,1)),('Rim strip',(-1,3,4),600,3,(1,1,1))]:
  d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size;d.color=col;o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.location=loc;aim(o,(0,0,.5))
 d=bpy.data.cameras.new('Shot camera');cam=bpy.data.objects.new('Shot camera',d);bpy.context.collection.objects.link(cam);s.camera=cam;cam.location=(2.3,-4.5,2.3);aim(cam,(0,0,.5));d.lens=63;d.dof.use_dof=True;d.dof.aperture_fstop=6;focus=empty('Focus on physical action');focus.location=(0,0,.5);d.dof.focus_object=focus
 return s,cam,focus
