import sys,pathlib,json,re,os,math
P=pathlib.Path('/workspace/work/hair-3d');sys.path.insert(0,str(P/'deps'))
os.environ['HF_HUB_DISABLE_XET']='1'
import numpy as np,torch,soundfile as sf
from scipy.signal import resample_poly
from transformers import AutoModelForCTC,AutoTokenizer
from uroman import Uroman
torch.set_num_threads(2)
name='MahmoudAshraf/mms-300m-1130-forced-aligner';cache=str(P/'hf-cache')
tokenizer=AutoTokenizer.from_pretrained(name,cache_dir=cache)
model=AutoModelForCTC.from_pretrained(name,cache_dir=cache).eval()
vocab=tokenizer.get_vocab();blank=model.config.pad_token_id;roman=Uroman();out=[]
print('MODEL_READY',len(vocab),blank,flush=True)
def align_ctc(probs,ids):
 # Viterbi alignment over the exact original transcript, including repeat-token
 # blank states. This never substitutes an ASR hypothesis for a script word.
 ext=np.full(len(ids)*2+1,blank,dtype=np.int64);ext[1::2]=ids;S=len(ext);T=len(probs)
 dp=np.full(S,-1e20,np.float32);dp[0]=0
 back=np.zeros((T,S),np.uint8)
 skip=(ext!=blank)&(ext!=np.roll(ext,2));skip[:2]=False
 for t in range(T):
  a=dp;b=np.r_[-1e20,dp[:-1]];c=np.r_[[-1e20,-1e20],dp[:-2]];c=np.where(skip,c,-1e20)
  options=np.stack([a,b,c]);choice=options.argmax(0);back[t]=choice
  dp=options[choice,np.arange(S)]+probs[t,ext]
 state=S-1 if dp[-1]>=dp[-2] else S-2;frames=[[] for _ in ids]
 for t in range(T-1,-1,-1):
  if state%2:frames[state//2].append(t)
  state-=int(back[t,state])
 return frames
for para in json.loads((P/'paragraphs.json').read_text()):
 i=para['paragraph'];wav,sr=sf.read(P/f'para{i}.wav',dtype='float32');g=math.gcd(sr,16000);wav=resample_poly(wav,16000//g,sr//g)
 with torch.inference_mode():p=model(torch.from_numpy(wav).unsqueeze(0)).logits[0].log_softmax(-1).numpy()
 words=para['text'].split();ids=[];spans=[]
 for word in words:
  normalized=re.sub('[^a-z]','',roman.romanize_string(word,lcode='kor').lower());token_ids=[vocab[c] for c in normalized if c in vocab]
  if not token_ids:raise RuntimeError('Unalignable original word: '+word)
  spans.append((len(ids),len(ids)+len(token_ids)));ids.extend(token_ids)
 aligned=align_ctc(p,ids);stride=len(wav)/16000/len(p)
 for word,(a,b) in zip(words,spans):
  frames=[f for token in aligned[a:b] for f in token]
  if not frames:raise RuntimeError('Missing CTC alignment for '+word)
  out.append({'word':word,'start':round(para['start']+min(frames)*stride,4),'end':round(para['start']+(max(frames)+1)*stride,4),'paragraph':i,'method':'MMS CTC Viterbi forced alignment of original word','confidence':round(float(np.mean([p[f,ids[k]] for k in range(a,b) for f in aligned[k]])),3)})
 print('ALIGNED',i+1,len(words),flush=True);(P/'words.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('DONE_WORDS',len(out),flush=True)
