import pathlib,sys,re,json,wave,numpy as np
P=pathlib.Path('/workspace/work/hair-3d');sys.path.insert(0,'/workspace/work/hair-v2/deps')
import sherpa_onnx,soundfile as sf
src=pathlib.Path('/workspace/attachments/ff10d77a-b238-4be1-81e2-151dbeb2598b/붙여넣은 텍스트.txt').read_text()
paras=[re.sub(r'^\d+\. ','',s) for s in src.split('■ 대본 (수정 금지)')[1].strip().splitlines() if s.strip()]
M=pathlib.Path('/workspace/work/hair-v2/sherpa-onnx-supertonic-3-tts-int8-2026-05-11')
cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(supertonic=sherpa_onnx.OfflineTtsSupertonicModelConfig(duration_predictor=str(M/'duration_predictor.int8.onnx'),text_encoder=str(M/'text_encoder.int8.onnx'),vector_estimator=str(M/'vector_estimator.int8.onnx'),vocoder=str(M/'vocoder.int8.onnx'),tts_json=str(M/'tts.json'),unicode_indexer=str(M/'unicode_indexer.bin'),voice_style=str(M/'voice.bin')),num_threads=2))
tts=sherpa_onnx.OfflineTts(cfg);gen=sherpa_onnx.GenerationConfig();gen.sid=1;gen.num_steps=16;gen.speed=1.0;gen.extra['lang']='ko'
master=[];timeline=[];at=0
for i,text in enumerate(paras):
 f=P/f'para{i}.wav'
 if not f.exists():
  a=tts.generate(text,gen);sf.write(f,a.samples,a.sample_rate)
 x,sr=sf.read(f,dtype='int16');d=len(x)/sr;timeline.append({'paragraph':i,'text':text,'start':at,'duration':d});master.append(x);master.append(np.zeros(round(.18*sr),np.int16));at+=d+.18;print(i+1,d,flush=True)
sf.write(P/'narration.wav',np.concatenate(master),sr,subtype='PCM_16')
(P/'paragraphs.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2));(P/'narration.txt').write_text(' '.join(paras));print('TOTAL',at,flush=True)
