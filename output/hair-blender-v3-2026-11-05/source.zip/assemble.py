import json,pathlib,subprocess,math,array,wave,sys,os
from PIL import Image,ImageDraw,ImageFont
import numpy as np
P=pathlib.Path(str(pathlib.Path(__file__).resolve().parent));plan=json.loads((P/'plan.json').read_text());O=P/'output';O.mkdir(parents=True,exist_ok=True)
def release_read_cache(path):
 if not hasattr(os,'posix_fadvise'):return
 fd=os.open(path,os.O_RDONLY)
 try:os.posix_fadvise(fd,0,0,os.POSIX_FADV_DONTNEED)
 finally:os.close(fd)

def region_mask(meta, size):
 # Static 64px seam feather stays inside the native bounds'96px safety margin.
 # No animated mask, object relocation, or temporal blending.
 w,h=size;x=np.ones(w,dtype=np.float32);y=np.ones(h,dtype=np.float32)
 n=min(64,w//2,h//2);r=np.linspace(0,1,n,dtype=np.float32);r=r*r*(3-2*r)
 if meta['x0']>0:x[:n]=r
 if meta['x1']<1:x[-n:]=r[::-1]
 if meta['y1']<1:y[:n]=r
 if meta['y0']>0:y[-n:]=r[::-1]
 return Image.fromarray(np.uint8(np.outer(y,x)*255),'L')

def ass_time(t):
 cs=round(t*100);return f'{cs//360000}:{cs//6000%60:02d}:{cs//100%60:02d}.{cs%100:02d}'
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Voice,Noto Sans CJK KR,58,&H00FFFFFF,&H00FFFFFF,&H00121A21,&H80121A21,-1,0,0,0,100,100,0,0,1,3,1.5,5,60,60,0,1
Style: Note,Noto Sans CJK KR,36,&H00FFFFFF,&H00FFFFFF,&H00202A30,&H80121A21,0,0,0,0,100,100,0,0,1,2,1,5,40,40,0,1
Style: Tag,Noto Sans CJK KR,69,&H00FFFFFF,&H00FFFFFF,&H00202A30,&H80121A21,-1,0,0,0,100,100,0,0,1,3,1,5,30,30,0,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
events=[];event_records=[];subtitle_words=[]
def event(a,b,text,style='Voice',xy=(540,1267)):
 event_records.append((a,b,text,style,xy))
 events.append(f'Dialogue: 0,{ass_time(a)},{ass_time(b)},{style},,0,0,0,,{{\\pos({xy[0]},{xy[1]})}}{text}')
for c in plan['cuts']:
 groups=[];g=[]
 for w in c['words']:
  if g and (len(g)>=3 or sum(len(x['word'])+1 for x in g)+len(w['word'])>14):groups.append(g);g=[]
  g.append(w)
 if g:groups.append(g)
 for j,g in enumerate(groups):
  a=g[0]['start'];b=min(g[-1]['end']+.14,groups[j+1][0]['start']-.025 if j+1<len(groups) else c['end']);text=' '.join(w['word'] for w in g);event(a,b,text,xy=(540,1191 if c['cut']==33 else 1344 if c['cut'] in [29,40] else 1267));subtitle_words.extend(w['word'] for w in g)
assert subtitle_words==[w['word'] for c in plan['cuts'] for w in c['words']]
event(13.33,42.17,'원리 설명용 회전·이동 속도','Note',(540,1690))
event(112.125,126.125,'원리 설명용 회전·이동 속도','Note',(540,1690))
event(81.38,84.96,'짧은 롤러 2개','Tag',(540,235));event(130.5,135.9,'일주일 1~2회','Tag',(540,235))
event(49.38,100.38,'원리 시각화 연출, 특정 제품 아님\\N회전·이동 속도는 설명용 연출','Note',(540,1690))
event(90.04,95.58,'절단형은 드리미 TriCut 예시\\N나르왈 Freo X Ultra는 원뿔형·단일 지지 구조','Note',(540,1560))
event(95.58,100.38,'기존 단일 롤러','Note',(540,300))
event(95.58,100.38,'개선 분할 롤러 예시','Note',(540,910))
event(108.38,112.12,'기존 구조','Note',(540,450))
event(108.38,112.12,'개선 구조 예시','Note',(540,1000))
event(95.58,100.38,'가닥 수·동작 속도는 원리 설명용 연출','Note',(540,1560))
event(108.38,112.12,'가닥 수는 원리 설명을 위한 예시입니다','Note',(540,1560))
event(139.8583,143.125,'원리 시각화, 회전 속도는 설명용','Note',(540,1690))
event(130.5,136.25,'관리 주기는 모델 설명서·사용 환경에 따라 다릅니다','Note',(540,1560))
(P/'captions.ass').write_text(header+'\n'.join(events)+'\n')
(P/'captions_trial.ass').write_text(header+'\n'.join(line for line,rec in zip(events,event_records) if rec[0]<33.975 and rec[1]>24.125)+'\n')
# A quiet, original synthesized ambient score and semantic Foley, no external samples.
def make_mix():
 import numpy as np,soundfile as sf
 voice,sr=sf.read(P/'narration.wav',dtype='float32');N=round(plan['duration']*sr);voice=np.pad(voice,(0,max(0,N-len(voice))))[:N];t=np.arange(N,dtype=np.float32)/sr
 music=np.zeros(N,dtype=np.float32)
 for freq,amp in [(110,.0015),(164.8138,.001),(220,.0007),(277.183,.0005)]:music+=amp*np.sin(2*np.pi*freq*t)*(0.8+0.2*np.sin(2*np.pi*.08*t))
 music*=3*np.minimum(1,t/2)*np.minimum(1,(plan['duration']-t)/2)
 rng=np.random.default_rng(20261105);fx=np.zeros(N,dtype=np.float32)
 for c in plan['cuts']:
  # Short, restrained air/handling transitions, never louder than the voice.
  start=round(c['start']*sr);n=min(round(.12*sr),N-start);u=np.arange(n)/sr;noise=rng.normal(0,1,n).astype(np.float32);fx[start:start+n]+=.005*noise*np.sin(np.pi*u/.12)**2
 for sec in [24.4185,31.2213,129.474,138.93]:
  k=round(sec*sr);n=min(round(.10*sr),N-k);u=np.arange(n)/sr;fx[k:k+n]+=.018*np.sin(2*np.pi*1200*u)*np.exp(-u*65)
 mix=voice*.92+music+fx;mix=np.clip(mix,-.98,.98);sf.write(P/'mixed.wav',mix,sr,subtype='PCM_16')
make_mix()
if '--prepare' in sys.argv:sys.exit()
trial='--trial' in sys.argv
out=P/'trial_10s.mp4' if trial else O/'hair_pixel.mp4';a=24.125 if trial else 0;dur=10 if trial else plan['duration']
cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','24','-i','pipe:0','-ss',str(a),'-i',str(P/'mixed_master.wav'),'-map','0:v','-map','1:a','-t',str(dur),'-vf',f"bilateral=sigmaS=2:sigmaR=0.06:planes=1,gblur=sigma=0.28,ass={P/'captions.ass'}" if not trial else f'bilateral=sigmaS=2:sigmaR=0.06:planes=1,gblur=sigma=0.28,setpts=PTS+24.125/TB,ass={P/"captions_trial.ass"},setpts=PTS-24.125/TB','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',str(out)]
if trial:cmd[cmd.index('-c:v'):cmd.index('-c:v')]=['-af','atrim=duration=9.85,apad=pad_dur=0.15']
process=subprocess.Popen(cmd,stdin=subprocess.PIPE)
if trial:
 for f in range(580,820):
  im=Image.open(P/'trial_float'/f'full_{f:05d}.png').convert('RGB');assert im.size==(1080,1920);process.stdin.write(im.tobytes())
else:
 for i in range(1,41):
  D=P/'render'/f'cut_{i:02d}';meta=json.loads((D/'metadata.json').read_text());plate=Image.open(D/'plate.png').convert('RGB') if meta['region'] else None
  mask=None
  for f in range(meta['start_frame'],meta['end_frame']+1):
   im=Image.open(D/f'{f:05d}.png').convert('RGB')
   if plate is not None:
    if mask is None:mask=region_mask(meta,im.size)
    full=plate.copy();full.paste(im,(round(meta.get('x0',0)*1080),1920-round(meta['y1']*1920)),mask);im=full
   assert im.size==(1080,1920);process.stdin.write(im.tobytes())
   release_read_cache(D/f'{f:05d}.png')
  print('ASSEMBLED_CUT',i,flush=True)
process.stdin.close();assert process.wait()==0
print('VIDEO_READY',out)
